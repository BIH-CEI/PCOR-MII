# Beispiel-Patientin (DEM) - PCOR-MII Implementation Guide v0.3.0

## Beispiel Patient: Beispiel-Patientin (DEM)

-------

**German**

-------

Language: de-DE

Anonymous Patient Female, DoB: 1985-03-12

-------



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "pcor-mii-exa-patient",
  "language" : "de-DE",
  "gender" : "female",
  "birthDate" : "1985-03-12"
}

```
