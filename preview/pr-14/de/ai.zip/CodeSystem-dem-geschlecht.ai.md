# DEM Geschlecht (Selbstbeschreibung) - PCOR-MII Implementation Guide v0.3.0

## CodeSystem: DEM Geschlecht (Selbstbeschreibung) (Experimentell) 

 
Selbstbeschriebenes Geschlecht (Q_SEX). HINWEIS: Im MII-Kontext bevorzugt an das MII-Person-Modul (Geschlecht / gender-amtlich-de) angleichen. 

Dieses CodeSystem wird in der Definition der folgenden ValueSets referenziert:

* [DEM Geschlecht](ValueSet-dem-geschlecht-vs.md)

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "dem-geschlecht",
  "url" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/dem-geschlecht",
  "version" : "0.3.0",
  "name" : "DemGeschlechtCS",
  "title" : "DEM Geschlecht (Selbstbeschreibung)",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-09-30T09:36:19+00:00",
  "publisher" : "BIH-CEI",
  "contact" : [{
    "name" : "BIH-CEI",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org/"
    }]
  }],
  "description" : "Selbstbeschriebenes Geschlecht (Q_SEX). HINWEIS: Im MII-Kontext bevorzugt an das MII-Person-Modul (Geschlecht / gender-amtlich-de) angleichen.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 5,
  "concept" : [{
    "code" : "weiblich",
    "display" : "Female",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Weiblich"
    }]
  },
  {
    "code" : "maennlich",
    "display" : "Male",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Männlich"
    }]
  },
  {
    "code" : "nicht-binaer",
    "display" : "Non-binary",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Nicht-binär"
    }]
  },
  {
    "code" : "andere",
    "display" : "Other",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Andere"
    }]
  },
  {
    "code" : "keine-angabe",
    "display" : "Prefer not to say",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Möchte ich nicht sagen"
    }]
  }]
}

```
