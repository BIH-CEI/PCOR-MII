# DEM Urbanizität - PCOR-MII Implementation Guide v0.3.0

## ValueSet: DEM Urbanizität (Experimentell) 

 
Wohnort-Typ (Q_OECDLITii). 

 **References** 

* [DEM — Demographics & Medical History](Questionnaire-DEM.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "dem-urbanizitaet-vs",
  "url" : "https://bih-cei.github.io/PCOR-MII/ValueSet/dem-urbanizitaet-vs",
  "version" : "0.3.0",
  "name" : "DemUrbanizitaetVS",
  "title" : "DEM Urbanizität",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-10-01T13:49:55+00:00",
  "publisher" : "BIH-CEI",
  "contact" : [{
    "name" : "BIH-CEI",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org/"
    }]
  }],
  "description" : "Wohnort-Typ (Q_OECDLITii).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/dem-urbanizitaet"
    }]
  }
}

```
