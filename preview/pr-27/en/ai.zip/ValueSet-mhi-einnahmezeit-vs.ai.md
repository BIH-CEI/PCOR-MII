# MHI Einnahmezeitpunkt Medikament - PCOR-MII Implementation Guide v0.3.0

## ValueSet: MHI Einnahmezeitpunkt Medikament (Experimental) 

 **References** 

* [MHI — Medical History](Questionnaire-MHI.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mhi-einnahmezeit-vs",
  "url" : "https://bih-cei.github.io/PCOR-MII/ValueSet/mhi-einnahmezeit-vs",
  "version" : "0.3.0",
  "name" : "MhiEinnahmezeitVS",
  "title" : "MHI Einnahmezeitpunkt Medikament",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-10-14T13:23:34+00:00",
  "publisher" : "BIH-CEI",
  "contact" : [{
    "name" : "BIH-CEI",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org/"
    }]
  }],
  "description" : "Tageszeit der Medikamenteneinnahme (medi_02_time).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/mhi-einnahmezeit"
    }]
  }
}

```
