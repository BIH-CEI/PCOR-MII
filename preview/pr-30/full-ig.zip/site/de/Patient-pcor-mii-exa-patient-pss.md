# Beispiel-Patient PSS - PCOR-MII Implementation Guide v0.9.0

## Beispiel Patient: Beispiel-Patient PSS

-------

**German**

-------

Language: de-DE

Anonymous Patient Male, DoB: 1977-09-03

-------



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "pcor-mii-exa-patient-pss",
  "language" : "de-DE",
  "gender" : "male",
  "birthDate" : "1977-09-03"
}

```
