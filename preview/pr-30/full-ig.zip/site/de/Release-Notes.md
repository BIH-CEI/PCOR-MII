# Release Notes - PCOR-MII Implementation Guide v0.9.0

## Release Notes

### Versionierung

Dieser IG folgt [Semantic Versioning 2.0.0](https://semver.org/):

* **MAJOR** — inkompatible Änderungen an normativem Inhalt (Item-Struktur, `linkId`s, Terminologie-Bindungen)
* **MINOR** — neue Questionnaires, Items, Beispiele oder abwärtskompatible Verbesserungen
* **PATCH** — Korrekturen von Fehlern in normativem Inhalt (falsche Codes, fehlerhafte Constraints)

Versionen `0.x.y` kennzeichnen die frühe Entwicklung — die Spezifikation ist noch nicht stabil. Version `1.0.0` markiert das erste stabile Release nach fachlicher Abstimmung und formaler Veröffentlichung.

Jede Änderung ist einer der folgenden Kategorien zugeordnet:

* **`feature`** — neuer Inhalt (Questionnaires, Items, ValueSets, Beispiele)
* **`improve`** — Verfeinerung oder Erweiterung bestehenden normativen Inhalts
* **`fix`** — Korrektur von Fehlern in normativem Inhalt
* **`documentation`** — Dokumentationsänderungen ohne Auswirkung auf normative Aspekte

-------

### v0.9.0 (unveröffentlicht) — MII PRO 2027 (ballot.2), itemWeight, SNOMED-Ja/Nein, NTx

**`breaking`** **ABQ entfernt** (2026-11-16): Der **Adherence Barriers Questionnaire** (Müller, Kohlmann & Wilke 2015) ist nicht mehr Teil des IG, weil seine Daten aus Lizenzgründen nicht an die DIZ übermittelt werden dürfen. Entfernt wurden Questionnaire `ABQ`, CodeSystem/ValueSet `abq-skala-4`, der Katalogcode `abq`, die Dictionary-Codes `ABQ_01`–`ABQ_16`, die Beispielantwort `ABQResponse` (auch im Bundle NTx — Erstbefragung) und der Eintrag im Manifest `use-case-ntxr` (jetzt 16 Bögen). Der BAASIS bleibt; seine Rolle als Auslöser des ABQ ist nur noch historisch dokumentiert. Siehe [Rechtelage](Rechtelage.md#ntx).

**`breaking`** **Umstieg auf das MII-PRO-Modul 2027.0.0-ballot.2** (SDC 4.0.0, ISiK 6.0.0): PCOR-MII erbt jetzt von der 2027er-Linie statt von 2026.7.0. Alle Upstream-Pins (`|2027.0.0-ballot.2`) in Manifesten und Beispielantworten, der [Validierungs-Container](Bereitstellung.md) (Dockerfile, compose, `application.yaml`, Package-Manifest) und die Validator-Kommandos auf [Validierung](Validierung.md) sind nachgezogen. Antworten, die `|2026.7.0` referenzieren, bleiben gültig, lösen aber nur mit dem alten Paket auf. Was bis zum finalen 2027-Release offen bleibt, führt [Kommende Änderungen](Kommende-Aenderungen.md)

**`breaking`** **`ordinalValue` → `itemWeight`:** Die Antwortgewichte der 15 eigenen Antwort-CodeSystems (72 Konzepte) heißen jetzt `itemWeight` mit der registrierten Property-URI `http://hl7.org/fhir/concept-properties#itemWeight` — Gewichte und Codes unverändert. Der Score-Ausdruck des OPD-SFK rechnet mit `.weight().sum()` statt `.ordinal().sum()`. Hintergrund: `ordinalValue` war nie eine registrierte Concept-Property (unsere Ballot-Einreichung HDB-972), SDC 4.0.0 kennt nur noch `itemWeight`; damit entfallen die 15 Publisher-Fehler „Unknown CodeSystem Property“. Konsumenten, die die Property `ordinalValue` lesen, stellen auf `itemWeight` um

**`improve`** **Version 0.9.0** statt 0.4.0: alle eigenen Pins (`|0.9.0`) in Manifesten, Beispielantworten, Bundles und eingebackenen Expansions nachgezogen; `version.fsh` bleibt die eine Stelle

**`improve`** **PROMIS-GH an das Upstream-Instrument gehängt:** Das Modul führt seit 2027.0.0-ballot.2 die vollständige PROMIS Scale v1.2 – Global Health (`mii-qst-pro-promis-global-health`, 10 Items, `draft`); `PROMISGH` ist per `derivedFrom` als 2-Item-Zuschnitt davon ausgewiesen. Offen: `linkId`-Angleichung an die Upstream-IDs (ADR-008) und ob der lokale Bogen entfällt — siehe [PROMIS](PROMIS.md)

**`documentation`** **Seite Beispiele:** die drei Beispielpatient:innen, vier Termin-Bundles und alle 45 Beispielantworten mit dem, was jede belegt, auf einer Seite [Beispiele](Beispiele.md) (de/en); Use-Case-Seiten, Fragebogen-Bibliothek, Validierung und Bereitstellung verweisen nur noch

**`fix`** **Beispiele korrigiert:** die Antwort zum PHQ-D Panik-Block fehlte im PSS-Screening-Bundle (jetzt 21 Entries); der OPD-SFK-Globalwert ist mit der OPD-SFK-Überarbeitung unten korrigiert

**`documentation`** **Seitenstruktur: eine Use-Case-Seite je Entität, Rechtelage gesammelt.** [PSS](PSS.md), [AN](AN.md) und die neue Seite [NTx](NTx.md) haben denselben Aufbau — Batterie als Tabelle mit Link auf die Ressource (PCOR-MII, MII PRO oder offen), spezifische Instrumente, Scores, Beispieldatensatz; die Seite „AN — Instrumentenliste“ ist in [AN](AN.md) aufgegangen, [NTx-Instrumente](NTx-Instrumente.md) hängt als Detailseite unter NTx. Rechtelage und Status aller Instrumente, die Bezugswege lizenzierter Bögen und **alle offenen Punkte** (Rechtefragen, PROMIS-GH, AN-Scoring, Dictionary-Errata, PHQ-SADS) stehen jetzt auf einer Seite [Rechtelage und offene Punkte](Rechtelage.md); die [Designentscheidungen](Designentscheidungen.md) enthalten nur noch die ADRs mit Index. Englische Fassungen für PSS, AN, NTx und Rechtelage. Alle Verweise auf das MII-PRO-Modul zeigen jetzt auf die Artefaktseiten seiner formalen Veröffentlichung (`medizininformatik-initiative.github.io/kerndatensatzmodul-proms/`, seit 2026-11-11 ballot.2) statt auf Simplifier-Guide- und Package-Seiten

**`improve`** **Ressourcensprache vereinheitlicht:** alle primär deutschen Questionnaires tragen `language = de-DE` (vorher gemischt `de`/`de-DE`); englisch-primäre Bögen bleiben `en` (ACE von `de` auf `en` korrigiert, weil `item.text` der ACE-Items englisch ist, ADR-005), die Schweizer PaRIS-Texte `de-CH`-Translations. Designations in den CodeSystems bleiben `de`

**`fix`** **QA-Bereinigung vor 0.9.0** (lokaler Publisher-Lauf 6.0.0-snapshot1): Anker des MHI-NTx-Abschnitts (12 defekte Links), ConceptMap-Verweise auf das MII-PRO-Modul als Text statt als nicht auflösbarer Link, toter `UKHD-AN`-Link der englischen Instrumentenseite; LOINC-Display `21112-8` auf „Birth date“, UCUM-Einheiten ohne Display wie im Modul; PHQ-15-Beispielantwort mit den deutschen Designations des Modul-CodeSystems. Die 15 `ordinalValue`-Fehler sind mit der `itemWeight`-Umstellung (oben) erledigt

**`breaking`** **Ja/Nein auf SNOMED CT umgestellt (ADR-013):** Alle sieben Bestandsbögen (DEM, MHI, ACE, EDE-Q6, UKHD-LE, UKHD-ND, PHQ-D Panik-Block; 26 Items) kodieren Ja/Nein jetzt inline als SNOMED CT `373066001`/`373067005`; `Q_MONMED` „Nicht zutreffend“ als `385432009`, `Q_GENDERID` „Möchte ich nicht sagen“ als LOINC `LA31066-6`. CodeSystem `dem-antwort` und die ValueSets `dem-ja-nein`, `dem-ja-nein-nz-vs`, `dem-ja-nein-ka-vs` sind **entfernt**. Antworten aus 0.3.0 mit `system …/CodeSystem/dem-antwort` validieren nicht mehr; Migrationsregel `ja → 373066001`, `nein → 373067005`, `nicht-zutreffend → 385432009`, `keine-angabe → LA31066-6`. `enableWhen`-Bedingungen, Beispielantworten und Bundles nachgezogen

**`feature`** **Beispielpatient NTx und Bundle NTx — Erstbefragung** (06.10.2026): [pcor-mii-exa-patient-ntx](Patient-pcor-mii-exa-patient-ntx.md) mit Beispielantworten zu MHI-NTx, NTx-Verlaufsbefragung, BAASIS und MTSOSD-R59 in [einem Bundle](Bundle-pcor-mii-exa-bundle-ntx-erstbefragung.md). Die beiden metadata-only-Antworten tragen nur `linkId`s und Codes; MTSOSD-R59 mit 11 aufgetretenen Symptomen (Tremor und Durchfall als Monitoring-Domänen) und Belastungsitems nur bei erfüllter `enableWhen`-Bedingung; Verlaufsbefragung als erster Bogen mit SNOMED-Ja/Nein (ADR-013). Damit hat jeder PCOR-MII-Bogen eine Beispielantwort

**`feature`** **ADR-014 — Variantenpaar für lizenzierte Bögen:** öffentliche metadata-only Definition in PCOR-MII (mit `enableWhen`/`required` als Austauschsemantik, ohne Display-Items), private erfassbare Variante (`derivedFrom`, Wortlaut, Antwortlabels per Display-Override, Display-Items, Capabilities displayable + collectable, Kennzeichnung `meta.tag`/`meta.security`) im getrennten Projekt **PCOR-MII-collectable**, das nur den Fragebogen-Server erreicht. Austauschregel: `QuestionnaireResponse` referenziert die öffentliche Definition, `item.text` leer. Ersetzt die verworfene Idee zweier Kopien unter einer Canonical; präzisiert ADR-012

**`documentation`** **MTSOSD-R59 — Scoring-Aussage präzisiert:** „kein Score" ist keine Lücke, sondern folgt der Originalpublikation (Dobbels et al. 2008): Summen sind nicht gerechtfertigt, der einzig korrekte Gesamtwert ist die kohortenrelative Ridit-Analyse, die nicht am Bogen stehen kann; `itemWeight` bleibt als Eingabe dafür gesetzt. Header, `designNote` und NTx-Seite angepasst

**`feature`** Neuer Questionnaire `PHQPANIK` — der PHQ-D Panik-Block (vier Ja/Nein-Screeningitems 3a–3d, Dictionary `phq3a`–`phq3d`), englisch primär (Brief PHQ, Pfizer) mit PHQ-D-Übersetzung, Sprungregel als `enableWhen`, `linkId`s im PHQ-D-Namespace (`phq-phq3a`–`phq-phq3d`), Beispielantwort für den PSS-Patienten; im PSS-Manifest ergänzt. In PCOR-MII gepflegt, weil das MII-PRO-Modul kein Artefakt führt (ADR-012)

**`feature`** **Use-Case-Manifeste NTXr und NTXd** — [use-case-ntxr](Library-use-case-ntxr.md) pinnt die generische Batterie plus WAI, BAASIS, MTSOSD-R59, MHI-NTx und NTx-Verlaufsbefragung; [use-case-ntxd](Library-use-case-ntxd.md) nur die generische Batterie (Spender haben laut Domain Overview kein spezifisches Instrument und kein Monitoring). PHQ-15 bewusst nicht gepinnt (Widerspruch zwischen Domain Overview und Dictionary-Blatt, Klärung offen). Damit haben alle vier Use Cases ein Manifest

**`feature`** **EQ-5D-5L in allen Manifesten** — die Modul-Variante `mii-qst-pro-euroqol-eq5d5l-collectable|2026.7.0` (Outcome, Prio A, jährlich, alle Use Cases) in PSS, AN, NTXr, NTXd und im Pilot-Manifest, das damit 12 Bögen pinnt

**`feature`** Neuer Questionnaire `NTXVERLAUF` — die quartalsweise Verlaufsbefragung des Standorts Hannover für NTx: 18 patient-reported Items der Dictionary-Gruppen `MHH-*` als ein Sammelbogen nach MHI-Muster (ISiKFormularDefinition), mit Dictionary-Gruppen als Gruppen-Items, `item.code` je Variable und Blutdruck als Gruppe mit LOINC-kodierten Wert-Items. Die drei MHH-Screening-Items (Spendeart, Transplantationsdatum, Anzahl Spendernieren) bilden den Ergänzungsbogen `MHINTX` zum MHI — eigener Bogen statt Szenario-Gruppe, weil der MHI allen Use Cases gemeinsam ist und die Zusammenstellung je Use Case über die Manifeste läuft. Ergänzung zu ADR-011 (Verlaufsbogen eines Standorts als Ressourceneinheit)

**`documentation`** **WAI — Rechtelage korrigiert:** Die Nutzungsbedingungen des FIOH erlauben den WAI ohne Genehmigung (Zitat Tuomi et al. 1998, kein Verkauf, eigener Name für Abwandlungen); der DIZ-Vermerk „wahrscheinlich nicht für die Veröffentlichung geeignet" ist unbelegt. Offen bleibt die Weitergabe des deutschen Wortlauts (WAI-Netzwerk Deutschland). Der Bogen bleibt bis zur Klärung metadata-only; Seite, Kommentar und `copyright` geben den Stand wieder, neuer offener Punkt in den Designentscheidungen

**`feature`** **ADR-013:** Ja/Nein nach der Best-Practice-Empfehlung des TC Terminologien als SNOMED CT `373066001`/`373067005` inline, RuleSet `JaNeinSnomed`; Nutzer sind die NTx-Verlaufsbefragung und BAASIS; die sieben Bestandsbögen folgen im selben Release (siehe `breaking`)

**`feature`** Neue metadata-only Questionnaires `BAASIS` und `MTSOSDR59` für den Use Case NTx — Struktur, `linkId`s, Antwortformate (neutrale Stufen mit `itemWeight`), Bedingungen und Bezugsweg ohne Originalwortlaut, da die Items nicht publiziert werden dürfen (© Universität Basel, © KU Leuven). BAASIS nach der offiziellen Erläuterung der Uni Basel nachgezogen: Item 5 ist die Phase Initiierung (seit Version 2020 offiziell, kein PCOR-MII-Zusatz), Scoring nach ABC-Taxonomie dokumentiert, die Teilfrage 2_a bekommt wegen ihrer Raten-Skala das eigene ValueSet `baasis-haeufigkeit-zeit-5-vs`, Lizenzbedingungen einschließlich Datenweitergabe-Klausel auf der Seite. MTSOSD-R59 ist über parametrisierte RuleSets aufgebaut (kein Generator); seine Belastung ist als eigene fünfstufige Skala `mtsosd-r59-belastung-5-vs` (Stufe 0–4, nach dem Blatt **Visual Scale MTSOSD-R59**) modelliert, Terminologie-Recherche ohne Treffer. Das NTx-Manifest bleibt zurückgestellt

**`documentation`** Neue Seiten PHQ-D Panik-Block und NTx-Instrumente; Instrumentenübersicht, PSS, PHQ-Übersicht und Fragebogen-Bibliothek nachgezogen; ADR-012 (Use-Case-spezifische Instrumente bleiben in PCOR-MII)

**`improve`** OPD-SFK: `linkId`s sind jetzt die Itemnummern der OPD-SF-Langform (`opdsf3` … `opdsf90`, Ehrenthal et al. 2015, Tabelle 2) statt der Dictionary-IDs `OPDSFK01`–`OPDSFK12`; `prefix` trägt die OPD-SFK-Nummer 1–12, `item.code` weiterhin die Dictionary-Variable. **Breaking für `QuestionnaireResponse`s gegen `OPDSFK|0.3.0`** — Migration und Dictionary-Abbildung über die neue ConceptMap `pcor-cm-opd-sfk-linkids`.

**`feature`** OPD-SFK: die drei explorativen Subskalen Selbstwahrnehmung (Items 1, 2, 5, 8), Beziehungsmodell (3, 7, 9, 12) und Kontaktgestaltung (4, 6, 10, 11) als berechnete readOnly-Items (Summenwert 0–16), Zuordnung aus Abbildung 1 der Publikation.

**`fix`** Beispielantwort `OPDSFKResponse`: der Globalwert war als Mittelwert (3.17) angegeben, korrekt ist der Summenwert 26; Subskalenwerte ergänzt, PSS-Screening-Bundle neu gebaut.

**`feature`** Neuer Questionnaire `PROMISGH` mit den PROMIS-Global-Health-Items Global01 `61577-3` und Global02 `61578-1` sowie ValueSet `promis-global-skala-5-vs` auf Basis der Answerlist `LL4280-5`. Übergangslösung bis zur Aufnahme der vollständigen 10-Item-Skala `85524-7` ins MII-PRO-Modul. Global07 ist über PROMIS-29 abgedeckt

**`documentation`** PROMIS-Seite um einen Abschnitt zu PROMIS Global Health erweitert mit Item-Tabelle, Antwortskala, Übergangscharakter und Abgrenzung zu Global07

**`feature`** ISiK-Formularprofile mit neuer Abhängigkeit `de.gematik.isik 5.1.1`. `DEM`, `MHI`, `GSLTPAQ`, `OPD-SFK` und `WAI` sind als `ISiKFormularDefinition` ausgewiesen, `DEMResponse`/`DEMPSSResponse` und `MHIResponse`/`MHIPSSResponse` als `ISiKFormularDaten` (mit `questionnaireDisplay`-Slice)

**`improve`** Profil-Canonicals zentral in `Aliases.fsh` gepflegt. `meta.profile` folgt der Konvention aus dem Bereitstellungs-Review: ohne Versionspin — die Auflösung läuft über die Paketabhängigkeit

**`improve`** SDC-Profil aus `meta.profile` der Nicht-PRO-Fragebögen entfernt. SDC bleibt Abhängigkeit, die verwendeten SDC-Extensions sind unberührt

**`breaking`** Platzhalter `PcorExampleQuestionnaire` **entfernt**, mit CodeSystem/ValueSet `pcor-example-general-health` und der Beispielantwort `pcor-mii-exa-example-response`. Er trug keinen Katalogcode und seine Beispielantwort pinnte noch `|0.1.0`; als Vorlage dient jeder reale Bogen. Wer die Canonical referenziert hat, muss umstellen

**`feature`** **Use-Case-Manifeste**: je aktivem Use Case eine `Library` (type `asset-collection`) mit allen Questionnaire-Canonicals versioniert gepinnt — [use-case-pss](Library-use-case-pss.md) (21) und [use-case-an](Library-use-case-an.md) (24), plus CodeSystem [pcor-use-case](CodeSystem-pcor-use-case.md) (5 Codes; NTXr/NTXd zurückgestellt). Dazu ein drittes Manifest für den Pilot „50 First Patients“: [pilot-50fp](Library-pilot-50fp.md) (11) pinnt die **Schnittmenge** aller Use Cases — abgeleitet aus den Use-Case-Spalten der [Fragebogen-Bibliothek](Fragebogen-Bibliothek.md#use-cases), keine eigene Auswahl.

**`documentation`** Die Zeile „PROMIS SF 4a (8 Domänen)“ des Erhebungsplans ist als **PROMIS-29 + Cognitive Function SF 4a** (PROMIS-33-Abdeckung) ausgewiesen — in der [Fragebogen-Bibliothek](Fragebogen-Bibliothek.md), der AN-Instrumentenliste (seit 0.9.0 in [AN](AN.md) aufgegangen) und den drei Manifesten. Die frühere Lesart mit der alleinstehenden Depression SF 4a war falsch. Bewusst **kein** `useContext` auf den Bögen — die Zugehörigkeit lebt an einer Stelle und erfasst auch Upstream-Bögen; Rückwärtssuche über den Standard-Suchparameter `Library?composed-of=`. CRMI-fähige Server liefern damit die Batterie eines Use Case in einem Zug. Alle drei Manifeste deklarieren das CRMI-Profil `crmi-manifestlibrary` (neue Abhängigkeit `hl7.fhir.uv.crmi 2.0.0`); befüllt ist der Slice `component` (`composed-of`), der Slice `dependency` (`depends-on`) und die Expansionsparameter bleiben für einen späteren `$package`-Einsatz offen. PROMIS-16 und PROMIS-29 + Cognitive Function SF 4a sind in allen Manifesten als **Standortvarianten** markiert (CRMI-Extension `crmi-intendedUsageContext`, als Text ohne eigenes CodeSystem); beide bleiben enthalten, weil Empfänger beide Standorttypen auflösen müssen.

**Der Wechsel auf das 2027-Modul ist mit diesem Release vollzogen (ballot.2); was bis zum finalen 2027-Release offen bleibt, steht auf [Kommende Änderungen](Kommende-Aenderungen.md).**

**`feature`** **Beispielpatienten je Use Case**: Patientin AN (zwei Termine: Initial 18.06., Monitoring 30.07.2026) und Patient PSS (Screening 25.06.2026), je Termin ein `collection`-Bundle — [AN-Initial](Bundle-pcor-mii-exa-bundle-an-initial.md) (13 Entries), [AN-Monitoring](Bundle-pcor-mii-exa-bundle-an-monitoring.md) (10), [PSS-Screening](Bundle-pcor-mii-exa-bundle-pss-screening.md) (20, vollständige Batterie inkl. zwölf Antworten auf MII-PRO-Questionnaires). Der Monitoring-Termin bringt die erste UKHD-ND- und die erste UKHD-EDP-Antwort; die vertagten Beispielantworten (OPD-SFK, GSLTPAQ, EXPECT, IPQ-S, WAI) sind nachgeliefert. `pcor-mii-exa-patient` heißt jetzt `pcor-mii-exa-patient-an`. Details: [Fragebogen-Bibliothek](Fragebogen-Bibliothek.md).

**`breaking`** Der [ACE](ACE.md) ist ein **PCOR-MII-Komposit**: die sechs `UKHD-CTT`-Zeitangaben sind per `enableWhen` an `ace1`–`ace3` gebunden (so gibt es das Dictionary vor; `enableWhen.question` trägt nur innerhalb eines Questionnaire). Titel, `copyright` (zwei Rechtequellen) und `language` (`de`) entsprechend; `item.code`/`instrument` unverändert. Details auf der [ACE-Seite](ACE.md).

**`feature`** **UKHD-Zusatzitems AN** als **sechs eigene Questionnaires** (je Dictionary-Gruppe: PT, ANB, CT, LE, ND, D) statt eines Sammelbogens — das `UKHD`-Präfix ist ein Zusammenstellungs-Etikett, keine Instrumenten- oder Autorenschaftsangabe; Rechte- und Herkunftsfrage werden je Gruppe geklärt. `UKHD-BI` bleibt unmodelliert (Bildskala ohne Bildvorlage). Begründung, Antwortskalen und neun Dictionary-Befunde: [UKHD-Zusatzitems](UKHD-Zusatzitems.md).

**`feature`** **UKHD-EDP** als metadata-only-Bogen (11 Items, vermutlich EDI-2-Zuschnitt; ohnehin keine Freigabe) — [UKHD-EDP](UKHD-EDP.md).

**`feature`** **Questionnaire-Katalog** [`pcor-questionnaire-catalogue`](CodeSystem-pcor-questionnaire-catalogue.md): ein lokaler Code je PCOR-MII-Bogen auf `Questionnaire.code` (die Canonical identifiziert das Artefakt, `code` das Konzept; ADR-003/-004/-007/-009 nachgezogen). Codes bezeichnen den Zuschnitt, nicht das Vollinstrument.

**`fix`** **Der ERQ-6 ist nicht der ERQ-S** — Identifikation und beide Scores zurückgezogen; der Bogen selbst (Wortlaut, `linkId`s) war und ist korrekt. Hergang und Tabelle-1-Abgleich: [ERQ-6](ERQ-6.md).

**`fix`** **Bereitstellungs-Review** über [Validierung](Validierung.md), [Anwendung](Implementation.md) und [Bereitstellung](Bereitstellung.md): Simplifier-Links und Container auf 2026.7.0, HAPI-Version, Artefakt-Tabelle (20 eigene Bögen), Beispielabschnitte auf die Bundles umgestellt; Konvention klargestellt — `meta.profile` ohne, `questionnaire`-Referenz mit Versionspin (die PROMIS-Altbeispiele machten es umgekehrt).

**`documentation`** Neue Seite [Fragebogen-Bibliothek](Fragebogen-Bibliothek.md) (de/en) nach dem MII-PRO-Muster; das Fragebögen-Menü von 24 Einträgen auf einen reduziert. Englische Fassung der [UKHD-Zusatzitems](UKHD-Zusatzitems.md); die Seite „Essstörungen — Erhebungsplan" ist entfernt (Quelle bleibt das Domain-Overview-Blatt, Nachschlag: AN-Instrumentenliste (seit 0.9.0 in [AN](AN.md) aufgegangen)). Neun Dictionary-Befunde als `designNote` an den betroffenen Items.

**(noch keine Einträge)**

**`feature`** Neue Seite **AN — Instrumentenliste (seit 0.9.0 in [AN](AN.md) aufgegangen)**: eine Nachschlagetabelle für den Use Case AN, die je Instrument direkt auf die Ressource verlinkt — PCOR-MII-Artefaktseite oder MII-PRO-IG. Die drei bestehenden AN-Seiten beantworten die Frage „wo liegt der Fragebogen, den ich erheben soll" jeweils nur teilweise: [AN](AN.md) beschreibt die Batterie fachlich, [Instrumente](Instrumente.md) alle drei Entitäten gemischt. Die neue Seite trennt Ressource (wo liegt sie) von Doku (was steht drin) in eigene Spalten und weist die drei Zustände **PCOR-MII / MII PRO / offen** explizit aus, statt sie in Prosa zu verstecken. Enthält zusätzlich die Scores, die UKHD-Itemgruppen mit ihrem Freigabestatus und einen Abgrenzungsabschnitt, was in AN **nicht** erhoben wird

**`fix`** Toter Link auf [WHODAS 2.0](WHODAS-12.md) korrigiert. Die IG-Doku-Seite im MII-PRO-IG trug ein `.page.md` zu viel und lieferte **404**. Instrumentenseiten liegen dort als Abschnitts-URL ohne `.page.md` (`…/PRO-Bibliothek/WHODAS-2.0?version=current`), nur echte Unterseiten tragen das Suffix — deshalb funktioniert der PROMIS-16-Link (`…/PROMIS/PROMIS-16.page.md`) und der WHODAS-Link nicht. Alle Upstream-Links der neuen Instrumentenliste sind einzeln gegen den veröffentlichten Guide geprüft, nicht aus dem Muster abgeleitet

**`fix`** Falsche Angabe auf der [PROMIS](PROMIS.md)-Seite korrigiert: PROMIS-29 und PROMIS-16 überlappen sich in **11**, nicht 14 Items, und **PROMIS-16 ist kein PROMIS-29-Subset plus zwei Cognitive-Function-Items**. Gegen die Questionnaires im Dependency-Paket nachgezählt: Fünf PROMIS-16-Items sind spezifisch, und sie liegen in **drei** Domänen — `sleep25` und `sleep90` (die Sleep-Domäne teilt mit PROMIS-29 **kein einziges** Item), `srpper31-caps` (Social Roles) sowie `pc27r` und `pc-caps3r` (Cognitive Function). Die praktische Folge stand bisher nirgends: Wer PROMIS-29 + Cognitive Function SF 4a erhebt, kann daraus **keinen PROMIS-16 rekonstruieren** — auch nicht die Cognitive-Function-Domäne, weil die SF 4a vier andere Items nutzt. Die [PROMIS-33](PROMIS-33.md)-Abdeckung ersetzt also das PROMIS-33, nicht das PROMIS-16. Die richtige Zahl stand auf der PROMIS-16-Seite schon seit v0.3.0, auf der Übersichtsseite aber die alte

**`documentation`** [PROMIS-16](PROMIS-16.md) um einen Abschnitt **Domänen im Vergleich zu PROMIS-29** erweitert, weil die Frage „welche Domänen unterscheiden sich?" zwei verschiedene Antworten hat. Auf Domänenebene genau zwei Unterschiede (PROMIS-16 hat Cognitive Function, PROMIS-29 die Schmerzintensität als NRS). Auf **Score**-Ebene sind die Profile dagegen **durchweg** verschieden, auch in den sieben gemeinsamen Domänen: dieselbe Domäne, andere Kurzform — vier Items mit Summenscore gegen zwei Items mit Antwortmuster-Lookup. Ein `promis-29-…-tscore` steht damit **nicht** für den PROMIS-16-T-Score derselben Domäne. **Bei LOINC ist die Lage asymmetrisch**, und das ist der praktisch folgenreichste Befund: LOINC führt zwei Ebenen nebeneinander — bank-ebene Domänen-T-Scores (`PROMIS emotional distress - anxiety …`) und instrumentenspezifische (`PROMIS-29 Anxiety score T-score`). Für PROMIS-29 existiert der instrumentenspezifische Satz **vollständig** (`71955-9`–`71967-4`), für **PROMIS-16 gar nicht** (0 Treffer in LOINC 2.83, auch keine Item- oder Panel-Codes). Ein PROMIS-16-T-Score kann also nur den Bank-Code tragen — denselben, den ein PROMIS-29-T-Score derselben Domäne trägt. Wer beide Profile nur über `code.coding[loinc]` filtert, mischt sie unbemerkt; die Unterscheidung muss über MII-Katalogcode und `method.text` laufen

**`documentation`** Die **Sleep-Domäne des PROMIS-16** ist belegt zugeordnet. Sie irritiert, weil sie ein Item aus der Sleep-Disturbance- und eines aus der Sleep-Related-Impairment-Bank mischt — LOINC führt für beide getrennte T-Scores (`77860-5` vs. `77859-7`), und der Sektionstitel upstream lautet entsprechend zweideutig „Sleep-related Impairment / Sleep Disturbance". Die Entwicklungspublikation ist eindeutig: Die Domäne heißt **Sleep Disturbance**, und die Itemparameter des SRI-Items wurden auf die Sleep-Disturbance-Items kalibriert (Edelen et al. 2024). Ein PROMIS-16-Sleep-T-Score gehört damit unter `77860-5`. Nebenbefund derselben Stelle: Nur diese eine Domäne ist nicht auf eine reine Allgemeinbevölkerungsstichprobe zentriert, sondern auf eine kombinierte mit klinischer Stichprobe

**`documentation`** Zwei Inkonsistenzen in den **PROMIS-29-ObservationDefinitions upstream** dokumentiert, gefunden beim Durchgehen der LOINC-Zuordnung. Sechs der sieben Domänen-T-Scores nutzen den bank-ebenen Code, **Anxiety** dagegen als einzige den instrumentenspezifischen `71967-4`, obwohl mit `77862-1` ein Bank-Code vorliegt — unbegründet und für einen Cross-Walk zu PROMIS-16 hinderlich. Bei **Social Roles** ist die Bank-Wahl (`77854-8`) umgekehrt sachlich zwingend: Der instrumentenspezifische `71957-5` heißt „PROMIS-29 Satisfaction with participation in social roles score T-score" und benennt die Domäne des PROMIS-29 **v1.0** — ab v2.0 ist es **Ability to Participate in Social Roles and Activities**, eine andere Domäne mit eigener Kalibrierung, nicht bloß umbenannt. Für PCOR-MII derzeit folgenlos, weil hier keine PROMIS-Score-Observations modelliert werden

**`documentation`** Entscheidung festgehalten, die **acht PROMIS-16-Domänen-T-Scores nicht lokal in PCOR-MII anzulegen**, und begründet, warum das kein Widerspruch zum lokal geführten [PROPr](PROMIS-16.md#propr) ist: Der PROPr rechnet auf Domänen-θ und ist damit profilunabhängig — ein stabiles Artefakt unabhängig davon, welches PROMIS-Profil ihn speist. Die Domänen-T-Scores hängen dagegen an der 2-Item-Kurzform und damit an genau der Antwortmuster-Tabelle, die upstream erst für 2027 vorgesehen ist; acht lokale Codes mit noch offener Berechnungsvorschrift wären Migrationsschulden. Stattdessen steht die Lücke jetzt als siebenteilige, ticketfähige Liste auf der Seite — inklusive der LOINC-Zuordnung je Domäne und der fünf upstream noch offenen Item-Codes

### v0.3.0 (2026-09-30) — AN-Batterie, Designentscheidungen und Item-Zuordnung

**`documentation`** Bei allen fünf AN-Instrumenten ist jetzt in `designNote`, `Questionnaire.description` und auf der Instrumentenseite festgehalten, dass der **PCOR-MII-Code eines Items die Dictionary-Variable ist** — ein zweites lokales CodeSystem für dieselben Items gibt es bewusst nicht. Der Code bezeichnet das **Erhebungsfeld**, nicht die Itemnummer. Beim [ERQ-S](ERQ-6.md) fällt beides auseinander, und das ist die einzige Falle dieser Art im Projekt: Dictionary `erq4`, `erq5` und `erq6` liegen auf den ERQ-Items **6, 8 und 9**. Weil `erq6` in beiden Spalten vorkommt und dort Verschiedenes bezeichnet, fällt eine Fehlzuordnung nicht auf — die Seite zeigt die Zuordnung deshalb als Tabelle. Beim ACE stehen Dictionary-Variable und LOINC-Code nebeneinander; genau dafür ist `item.code` `0..*`

**`improve`** ERQ-S, EDE-Q6 und ACE auf **Englisch als Primärsprache** umgestellt (ADR-005) — alle drei haben ein englisches Original, waren aber deutsch-primär ohne Übersetzungsebene. `item.text` trägt jetzt den Originalwortlaut, die deutsche Fassung hängt als `translation` mit `lang = de` daran; beim EDE-Q6 zusätzlich die sieben Antwortkonzepte mit `designation`. Damit sind fünf der dreizehn Bögen englisch-primär (dazu DEM und ANSOCQ-2). Deutsch-primär bleiben die deutsch entwickelten und die projekteigenen Instrumente — beim [SSUK-2](SSUK-2.md) ausdrücklich begründet, weil sich die Items nicht als wörtliche ISSS-Items belegen lassen.

Die englischen Wortlaute sind **beschafft, nicht erinnert**: ERQ aus dem Originalbogen des [Stanford Psychophysiology Laboratory](https://spl.stanford.edu/resources), EDE-Q aus dem autorisierten Bogen EDE-Q 6.0 (© Fairburn and Beglin 2008, CREDO Oxford), ACE aus einem an Felitti et al. 1998 zitierenden Exemplar.

**Bei zwei Instrumenten verbessert das zugleich die Rechtelage**, weil sie nicht symmetrisch ist: Beim EDE-Q6 ist der englische Wortlaut frei bereitgestellt und der deutsche dgvt-verlegt; beim ACE ist das englische Original ein frei verwendetes Public-Health-Instrument, während die Freigabe der deutschen ACE-D-Fassung offen ist. Englisch primär verschiebt den jeweils heikleren Teil in eine Übersetzungsebene, statt ihn zum Hauptinhalt zu machen.

**`fix`** Zwei Funde beim Abgleich des EDE-Q6 gegen den Originalbogen. Item 12 heißt dort **„strong desire to lose weight“**, nicht „definite desire“ — die deutsche Fassung („starken Wunsch“) war richtig, meine frühere Notiz nicht. Und `edeq29`/`edeq30` sind im englischen EDE-Q 6.0 **gar nicht nummeriert**: Sie stehen in einem unnummerierten Schlussblock nach Item 28. Die Nummern stammen aus der deutschen Ausgabe; die `linkId`s folgen damit der deutschen Zählung, nicht dem Originalbogen. Beides jetzt im `designNote` und auf der Seite dokumentiert

**`documentation`** Wortlaut und Scoring des **ERQ-10** vollständig beschafft — englischer Originalbogen und autorisierte deutsche Fassung, je zehn Items. Die Langform wird nach ADR-008 **nicht in diesem Release** modelliert; gebraucht werden zunächst die Short Forms. Für den ERQ-S ist sie vor allem die Quelle des deutschen Wortlauts, den die Kurzform-Publikation nicht enthält

**`improve`** Zentrale Versionsverwaltung über RuleSets eingeführt (`input/fsh/rulesets/version.fsh`, Muster aus dem MII-PRO-Modul). Beim Release wird nur noch diese Datei angehoben. Vorher stand die Version in jeder Instanz hart drin — und war auseinandergelaufen: Der IG ging 0.1.0 → 0.2.0, während **alle 13 Questionnaires auf 0.1.0 stehen blieben**, darunter solche mit substanziell geändertem Inhalt (DEM: 19 Items auf Englisch als Primärsprache umgestellt; MHI: `copyright` und 46 `item.code`s ergänzt). Wer `canonical|0.1.0` gepinnt hatte, bekam für dieselbe Versionsangabe anderen Inhalt.

Dabei drei Lücken geschlossen, die vorher gar keine Version hatten: **26 CodeSystems und 27 ValueSets** (jetzt über `PR_CS_VS_Version`), die drei **ObservationDefinitions** (R4 hat dort kein `version`-Element — Backport über die `artifact-version`-Extension) und die eingebackenen ValueSet-**Expansions**, die ein `|0.1.0` am CodeSystem referenzierten, das dort nie deklariert war. Die Questionnaires deklarieren zusätzlich `versionAlgorithm = semver`, passend zur Versionierungsregel dieses IG.

Die sieben `QuestionnaireResponse`s referenzieren ihren Questionnaire jetzt **versioniert** (`…/Questionnaire/ERQ6|0.3.0`). Ohne Pin ist aus einer Antwort nicht ablesbar, welcher Wortlaut vorlag — bei mehreren Sprachebenen und bei Zuschnitten ist das die entscheidende Information. Validator nach der Umstellung: weiterhin 0 errors.

**`feature`** Dictionary-Variablen als `item.code` in allen zwölf PCOR-MII-Questionnaires hinterlegt (114 Items), gegen das neue generierte CodeSystem `pcor-item-dictionary` (`content = fragment`). Damit lässt sich ein flach erhobener Studiendatensatz maschinell auf die Instrumenten-Questionnaires verteilen. Der Mechanismus ist bewusst **nicht** der `linkId` und **nicht** eine ConceptMap: `linkId`s sind nur **innerhalb** eines Questionnaire eindeutig und können die Frage, zu welchem Instrument eine Variable gehört, grundsätzlich nicht beantworten — beim ERQ ordnet ein Abgleich über Namensgleichheit sogar still falsch zu. Ohne Code bleiben genau die Items, die keine Dictionary-Variablen sind: Gruppen-Items, berechnete Scores und PCOR-MII-eigene Hilfsitems wie die Einheitenauswahl `Q_WB151`/`Q_WB152` im MHI

**`documentation`** Fünf neue Designentscheidungen. **ADR-007**: Zwei unabhängige Übersetzungen werden zwei Questionnaires — ein Sprachtag behauptete eine sprachliche Varietät statt eines Validierungsunterschieds, ein Versionssprung behauptete Ablösung. **ADR-008**: Short Forms tragen Original-`linkId`s, ihr Wortlaut kommt aus der autorisierten Quelle der **Langform** (nicht aus der Kurzform-Publikation, die typischerweise nur Itemnummern nennt), und die Langform wird mitmodelliert, soweit beschaffbar. **ADR-009**: `derivedFrom` ist `canonical(Questionnaire)` und kann daher nicht auf einen Artikel zeigen; zwei Übersetzungen desselben Instruments sind Geschwister, nicht Eltern und Kind. **ADR-010**: sprachliche Anpassung nur als zusätzliche Ebene, mit vier getrennt behandelten Fällen — Helvetismus, Reform 1996, Getrennt-/Zusammenschreibung (nicht anfassen) und editorialer Druckfehler. **ADR-011**: Erhebungseinheit ist nicht Instrumenteneinheit — eigene Ressource nur für publizierte mehritemige Instrumente, Einzelitems in Sammelbögen

**`documentation`** Vier Rechte-Befunde aufgenommen, alle als offen markiert. **`UKHD-EDP`** ist trotz Standort-Präfix vermutlich kein Eigenbau, sondern ein EDI-2-Zuschnitt (je ein Item pro Subskala) — deutsch ein Hogrefe-Testverfahren, in der DIZ-Liste gar nicht geführt; die Zuordnung stützt sich auf Inhalt und Antwortformat, nicht auf einen Wortlautabgleich. Der Planungseintrag „EDEQ/EDP (UKHD)“ mit 17 Items sind damit **zwei** Instrumente, nicht eines. Die **deutsche ACE-D-Fassung ist nicht frei publizierbar** — das **Deutsche Ärzteblatt** druckt nur zwei von zehn Items und verweist für den Gesamtbogen auf den Rechteinhaber; das betrifft rückwirkend die fünf publizierten Items. Die **Standort-Itemgruppen** von UKHD, UKE und MHH führt die DIZ-Liste überhaupt nicht, 34 davon publiziert PCOR-MII bereits

**`fix`** ANSOCQ-2: Die Begründung der Einfachauswahl korrigiert. Rieger et al. 2002 erlauben ausdrücklich mehrere Feststellungen je Item und mitteln sie; Item 17 der Langform instruiert es sogar. Das frühere Argument, Mehrfachauswahl sprenge den Scorebereich 20–100, ist damit **zurückgezogen** — die Mittelung innerhalb des Items hält jedes Item bei 1–5. Einfachauswahl bleibt umgesetzt, aber als bewusste Abweichung vom Original, weil das Dictionary beide Items als „Single Answer“ führt

**`feature`** Beispieldatensatz für die AN-Batterie: fünf `QuestionnaireResponse`s und zwei ERQ-S-Score-`Observation`s als ein zusammenhängendes Szenario — dieselbe Beispiel-Patientin, die DEM und MHI schon nutzen, ein Erhebungstermin, gestaffelte Uhrzeiten. Die Antwortwerte sind begründet gewählt, nicht zufällig; ein durchgängig mittleres Profil hätte beim ERQ-S beide Subskalen-Summen auf denselben Wert gelegt und beim SSUK-2 die Gegenläufigkeit der Items verdeckt. Alle sieben mit dem FHIR-Validator geprüft: 0 errors

**`fix`** Beim Validieren ein Strukturfehler gefunden und behoben: Die ERQ-S-Beispielantwort hatte ihre Items nach Subskala gruppiert, was der Validator zurückweist („Elemente in falscher Reihenfolge“) — eine `QuestionnaireResponse` muss die Reihenfolge des Questionnaire einhalten. SUSHI fängt das nicht; jetzt auf der Validierungsseite dokumentiert

**`documentation`** Sechs neue Seiten für die upstream gepflegten spezifischen Instrumente: SCOFF, Whiteley-7, SSD-12, ISR-Z, PC-PTSD und EURONET-SOMA — referenziert, nicht nachgebaut (ADR-002). Drei Eigenheiten dabei festgehalten: Der **ISR-Z bildet einen Mittelwert** (0–4), keine Summe — die einzige Abweichung unter den sechs; der **Whiteley-7 hat zwei Cut-offs** (0/1 und 1/2), beide als Referenzintervall, weil der eine Sensitivität und der andere Spezifität maximiert; **EURONET-SOMA** setzt `calculatable = false`, weil zwei Einzelitems keine Skala sind und nicht summiert werden dürfen

**`documentation`** Neue Seite Essstörungen — der Erhebungsplan der AN-Batterie, ausgewertet aus dem Blatt `Domain Overview` des Item Level Dictionary: drei Phasen, Prioritäten A/B/C, Frequenzen, Itembudget, die Datenquellen PRO/CRO/EHR und die geplanten Scores. Zwei Befunde ordnen den Umsetzungsstand neu: Es sind **vier** Use Cases, nicht drei (NTx spaltet in Empfänger und Spender), und die „Langformen“ des Plans sind **nicht** die Vollinstrumente — ERQ-6 und ACE-5 **sind** bereits die größte vorgesehene Variante, ein EDE-Q-28, SSUK-26 oder ACE-10 kommt im Plan nirgends vor

**`documentation`** Die Auswahlregel der Zuschnitte („trennschärfstes Item je Skala“ laut DIZ-Implementierungsliste) auf allen betroffenen Seiten und maschinenlesbar in allen fünf `designNote`s hinterlegt — bisher stand sie nur bei EDE-Q6 und ANSOCQ-2. Für drei der vier ist sie gegen die publizierte Struktur des Originalinstruments nachgeprüft. Beim ERQ-S trifft der Singular nicht zu (drei Items je Subskala), beim ACE gilt stattdessen „die ersten 5 Fragen“; beides ist jetzt ausdrücklich vermerkt

**`documentation`** Wortlaut und Scoring des **ERQ-10** vollständig beschafft — englisches Original und die von Gross und John autorisierte deutsche Fassung (Abler & Kessler 2009), beide über das Stanford Psychophysiology Laboratory. Der offizielle Bogen nennt „no reversals“ und die Item-Zuordnung, aber **nicht** die Aggregation; er schreibt zudem die **Itemreihenfolge normativ** fest, weil Items 1 und 3 die Begriffe „positive“ und „negative emotion“ definieren

**`improve`** GSLTPAQ trägt jetzt `language = de` — bisher war es nicht gesetzt, obwohl der Text deutsch ist. Mit ausdrücklicher Begründung, warum hier von ADR-005 abgewichen wird: Die hausinterne Eigenübersetzung ist keine getreue Wiedergabe eines autorisierten Wortlauts, also ist Deutsch hier das Primäre und keine Übersetzungsebene

**`feature`** ANSOCQ-2 um eine `de`-Ebene ergänzt: orthografisch und grammatisch bereinigte deutsche Fassung neben der validierten `de-CH`-Übersetzung, ausdrücklich als nicht-validiert gekennzeichnet. Dabei ein **editorialer Druckfehler der Schweizer Vorlage** eingeordnet (Stufe 1 der Körperteile: „bereit an … zunehmen“ statt „zuzunehmen“): `de-CH` bleibt bewusst unverändert, weil es abbildet, was den Befragten vorlag — korrigiert wird ausschließlich in `de`

**`improve`** ANSOCQ-2 auf Englisch als Primärsprache umgestellt (ADR-005): `item.text` und die zehn Antwortkonzepte tragen den englischen Originalwortlaut aus Rieger et al. 2002, die Schweizer Fassung hängt als `de-CH`-Übersetzung bzw. -Designation daran

**`documentation`** ANSOCQ-2: Wortlaut und Nummerierung gegen den im Volltext abgedruckten Originalbogen verifiziert. Zwei Fassungen aufgeklärt — Rieger 2000 mit 23 Items, Rieger 2002 mit 20; die deutsche Übersetzung folgt der 20-Item-Revision, die Nummern 3 und 14 gelten in beiden Sprachen

**`documentation`** ANSOCQ-2: Auswahllogik und Nummerierung verifiziert — Pauli et al. (**J Eat Disord** 2017) nennen `item 3` als hochladend auf Faktor „weight gain and control" und `item 14` auf Faktor „attitudes and feelings"; die „Skalen" der DIZ-Angabe sind damit die Faktoren der deutschen Validierung. Dazu die Vergleichsarbeit von Wietersheim & Hoffmann (2011) als Kontext zur Instrumentenwahl ergänzt

**`documentation`** SSUK-2: Itemnummerierung verifiziert statt nur festgelegt — Müller, Mehnert & Koch (**Z Med Psychol** 2004) belegen in Tabelle 2 Item 14 („aufmuntert oder tröstet") und Item 10 („Auswirkung der Erkrankung herunterspielt"). Langfassung umfasst 26 Items (17 Positive Unterstützung + 9 Belastende Interaktion)

**`fix`** ACE: Wortlaut aller fünf Items gegen die deutsche Fassung ACE-D verifiziert — wortgleich; die Anführungszeichen um „high" in `ace5` an die typografische Form des Originals angeglichen. Nummerierung bestätigt: `ace1`–`ace5` sind die Items 1–5 des zehnteiligen Bogens

**`fix`** EDE-Q6: Wortlaut aller sechs Items und der Antwortskala gegen die autorisierte deutsche Übersetzung (Hilbert & Tuschen-Caffier, dgvt-Verlag 2016) verifiziert — wortgleich. Quellenkorrektur: Die DIZ-Liste nennt die **Diagnostica**-Evaluation von 2007, maßgeblich für den Wortlaut ist die dgvt-Ausgabe

**`documentation`** ADR-006: Der EDE-Q6-Wortlaut wird aufgenommen, gestützt auf die freie Bereitstellung des Fragebogens durch den Verlag selbst; der Rechtevorbehalt der Publikation bleibt im `copyright` ausgewiesen, eine Bestätigung der Rechteinhaberin wird angestrebt. Trägt ausdrücklich nicht für GI-PS

**`documentation`** EDE-Q6: Auswahllogik verifiziert — die vier Skalen-Items sind je eines pro Subskala (Restraint, Eating Concern, Weight Concern, Shape Concern); damit sind die `linkId`s als Original-EDE-Q-Nummern belegt

**`feature`** ConceptMap `pcor-cm-erq-s-linkids`: bildet die sequenziellen Dictionary-Variablen-IDs des ERQ auf die FHIR-`linkId`s ab. Nötig wegen einer Kollision — `erq6` existiert in beiden Systemen und bezeichnet dort verschiedene Items

**`documentation`** Quellenlage aller AN-Instrumente verifiziert: Entwicklungs- und Übersetzungspaper je Instrument aufgelöst und in `copyright` sowie auf den Seiten nachgetragen. Zwei Korrekturen — die **SSUK** ist die deutsche Adaptation der englischen **Illness-specific Social Support Scale** (Revenson et al. 1991), kein deutsches Original; beim **ANSOCQ-2** verweist die DIZ-Liste auf das Stadienmodell (Prochaska & DiClemente 1982) statt auf das Instrument (Rieger et al. 2000). Außer dem ERQ-S ist keiner der Zuschnitte eine offizielle Kurzform

**`feature`** ERQ-S als offizielle ERQ-Kurzform identifiziert und mit validiertem Scoring modelliert — **diese Aussage war falsch und ist am 01.10.2026 zurückgezogen, siehe oben unter Unveröffentlicht.** Ursprünglicher Eintrag: zwei Subskalen-`ObservationDefinition`s (Neubewertung `erq1`+`erq3`+`erq8`, Unterdrückung `erq2`+`erq6`+`erq9`, je 3–21) sowie FHIRPath-`variable`s im Questionnaire. US-Normwerte bewusst nicht als Referenzintervalle hinterlegt

**`fix`** ACE: item-genaue LOINC-Codes ergänzt (`82814-5` bis `82818-6` aus den Panel-Komponenten von `82813-7`) — der Panel-Code selbst bleibt dem 5-Fragen-Zuschnitt weiterhin nicht zugewiesen

**`feature`** AN-Instrumente ERQ-S, EDE-Q6, ANSOCQ-2, SSUK-2 und ACE als PCOR-MII-eigene Questionnaires vorbereitet — vorläufig zum Testen, spätere Aufnahme ins MII-PRO-Modul möglich; ohne Vollinstrument-Codes und (außer beim ERQ-S) ohne Scores, da für die Zuschnitte keine validierte Vorschrift vorliegt (ADR-003)

**`documentation`** Neue Seiten: AN-Entitätsseite, je eine Seite pro AN-Instrument sowie Designentscheidungen (Entscheidungslog aus `docs/decisions.md` in den IG umgezogen)

**`documentation`** ADR-004: Score-Artefakte gehören der Zuständigkeit nach ins MII-PRO-Modul. Ein lokaler Katalogcode ist aber zulässig, wo weder LOINC noch SNOMED CT noch der MII-Katalog einen führt — das Blueprint-Profil bindet `code.coding` nicht, sondern sliced offen, sodass ein künftiger MII-Code ergänzt statt ersetzt wird

**`improve`** Designentscheidungen zusätzlich maschinenlesbar in den Questionnaires abgelegt (`designNote`-Extension, bogen- und itemweit)

**`feature`** PROPr (PROMIS-Preference Utility Score) als `ObservationDefinition` `PcorObsDefProprUtility` samt lokalem Score-Katalog `pcor-score-catalogue` — konform zum `mii-pr-pro-score-blueprint`, Wertebereich −0,022 bis 1,0, ohne ausführbare Berechnung (MDR-Abgrenzung). Vorläufig hier gepflegt; Zuständigkeit liegt beim MII-PRO-Modul

**`documentation`** PROMIS-16-Seite korrigiert: drei statt zwei Scores, PROPr nutzt nur sieben der acht Domänen (ohne Anxiety), kein Schmerzintensitäts-Item, Item-Überlapp mit PROMIS-29+2 sind 11 statt 14 Items; die Zusage „Scoring in MII PRO 2026.5.0" ist upstream inzwischen Roadmap 2027

**`improve`** DEM mehrsprachig nach MII-PRO-Konvention: 19 Items tragen den englischen PaRIS-Originalwortlaut als `item.text` mit der Schweizer Fassung als `de-CH`-`translation`; sechs DEM-eigene Antwortskalen englische Displays mit `de-CH`-Designation. Der übernommene Wortlaut bleibt dabei unverändert (ADR-005)

**`documentation`** ADR-005: Übernommener Wortlaut wird nicht eingedeutscht — Erhalt der TRAPD-Validierung, Nachnutzung statt Adaption; Schweizer Herkunft wird stattdessen als `de-CH` ausgewiesen

**`fix`** Rechteangaben ergänzt: DEM hatte bisher kein `copyright`-Element — jetzt mit OECD-PaRIS-Nennung, Link auf den Originalbogen und dem von der OECD vorgeschriebenen Übersetzungs-Disclaimer; MHI und DEM weisen zusätzlich den offenen GI-PS-Weitergabevorbehalt aus

**`improve`** MII-PRO-Abhängigkeit auf 2026.7.0 angehoben (GAD-7 im PHQ-D-Namespace)

**`feature`** Neue Seite GAD-7; PHQ-Übersicht um GAD-7, PHQ-4 und die ConceptMap `mii-cm-pro-gad-7-linkids` ergänzt

**`feature`** EXPECT und IPQ-S als PCOR-MII-eigene Ressourcen modelliert (beide nicht im MII-PRO-Modul); EXPECT bewusst ohne Gesamtscore, IPQ-S ausdrücklich als einzelne B-IPQ-Ursachenfrage und nicht als B-IPQ

**`documentation`** Neue Instrumentenübersicht über alle drei Entitäten und eigene PSS-Seite

**`documentation`** Neue Seiten für die PCOR-MII-eigenen Instrumente OPD-SFK, WAI und GSLTPAQ

**`improve`** MII-PRO-Abhängigkeit auf 2026.6.0 angehoben (rein additiv gegenüber 2026.5.2: neue Questionnaires EURONET-SOMA, ISR-Z, PC-PTSD, SCOFF, SSD-12, WI-7 samt Score-`ObservationDefinition`s)

**`feature`** OPD-SFK, WAI und GSLTPAQ als PCOR-MII-eigene Instrumente (nicht im MII-PRO-Modul enthalten)

### v0.2.0 (2026-08-05) — PHQ-Familie

**`improve`** MII-PRO-Abhängigkeit auf 2026.5.2 angehoben (PHQ-9 neues `linkId`-Schema, PHQ-15, Migrations-ConceptMap)

**`feature`** Neue Seite PHQ-9

**`feature`** Neue PHQ-Übersicht mit `linkId`-Migrationstabelle (2026.4.x → ab 2026.5.0)

**`documentation`** PHQ-15 und PHQ-9 als schlanke Referenzseiten (Details upstream statt dupliziert); toten Simplifier-Link entfernt

**`fix`** MHI: falschen Hinweis „GIPS13 nicht in PSS" entfernt — GIPS13 ist in allen drei Szenarien enthalten

### v0.1.0 (2026-06-04) — Initial Draft

**`feature`** Erstaufbau des PCOR-MII Implementation Guide mit BIH-Corporate-Design-Template, Mehrsprachigkeit (Deutsch als Standardsprache, Englisch als Übersetzung) und CI/CD-Pipeline (GitHub Actions → GitHub Pages)

**`feature`** Beispiel-Questionnaire `PcorExampleQuestionnaire` als Vorlage (Item-Typen `group`, `choice`, `date`, `string`)

**`documentation`** Seitenstruktur: Startseite, Fragebögen, Anwendung (QuestionnaireResponse, Population, Extraktion), Release Notes

**`documentation`** CC-BY-4.0-Lizenz

