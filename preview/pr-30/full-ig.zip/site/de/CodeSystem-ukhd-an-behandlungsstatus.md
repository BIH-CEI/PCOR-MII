# UKHD-AN Aktueller Behandlungsstatus (Codes) - PCOR-MII Implementation Guide v0.9.0

## CodeSystem: UKHD-AN Aktueller Behandlungsstatus (Codes) (Experimentell) 

Dieses CodeSystem wird in der Definition der folgenden ValueSets referenziert:

* [UKHD-AN Aktueller Behandlungsstatus](ValueSet-ukhd-an-behandlungsstatus-vs.md)

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ukhd-an-behandlungsstatus",
  "url" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/ukhd-an-behandlungsstatus",
  "version" : "0.9.0",
  "name" : "UkhdAnBehandlungsstatusCS",
  "title" : "UKHD-AN Aktueller Behandlungsstatus (Codes)",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-11-16T14:09:46+00:00",
  "publisher" : "BIH-CEI",
  "contact" : [{
    "name" : "BIH-CEI",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org/"
    }]
  }],
  "description" : "Vier Stufen des aktuellen psychotherapeutischen Behandlungsstatus (`treatment_outpatient`). Bewusst ohne `itemWeight`: Die Skala mischt Behandlungsstatus (Stufen 1/2) und Setting (Stufen 3/4).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 4,
  "concept" : [{
    "code" : "1",
    "display" : "nein"
  },
  {
    "code" : "2",
    "display" : "nein, aber es ist eine Behandlung geplant oder ich befinde mich noch auf der Suche"
  },
  {
    "code" : "3",
    "display" : "Ja, ich befinde mich zurzeit in ambulanter psychotherapeutischer Behandlung"
  },
  {
    "code" : "4",
    "display" : "ja, ich befinde mich aktuell in einer klinischen (stationären) oder tagesklinischen (teilstationären) Behandlung"
  }]
}

```
