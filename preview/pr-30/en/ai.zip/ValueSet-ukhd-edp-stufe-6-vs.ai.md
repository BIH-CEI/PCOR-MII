# UKHD-EDP Antwortstufen (neutralisiert) - PCOR-MII Implementation Guide v0.9.0

## ValueSet: UKHD-EDP Antwortstufen (neutralisiert) (Experimental) 

 **References** 

* [UKHD-EDP — Essstörungspathologie (11 Items, metadata-only)](Questionnaire-UKHDEDP.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ukhd-edp-stufe-6-vs",
  "url" : "https://bih-cei.github.io/PCOR-MII/ValueSet/ukhd-edp-stufe-6-vs",
  "version" : "0.9.0",
  "name" : "UkhdEdpStufe6VS",
  "title" : "UKHD-EDP Antwortstufen (neutralisiert)",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-11-16T14:09:46+00:00",
  "publisher" : "BIH-CEI",
  "contact" : [{
    "name" : "BIH-CEI",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org/"
    }]
  }],
  "description" : "Antwortstufen des UKHD-EDP in neutralisierter Form — siehe CodeSystem.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/ukhd-edp-stufe-6"
    }]
  }
}

```
