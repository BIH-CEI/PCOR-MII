# DEM Antwortoptionen (Ja/Nein/Nicht zutreffend/Keine Angabe) - PCOR-MII Implementation Guide v0.3.0

## CodeSystem: DEM Antwortoptionen (Ja/Nein/Nicht zutreffend/Keine Angabe) (Experimental) 

 
Gemeinsames CodeSystem für die Ja/Nein-Items des DEM. Frage-spezifische Subsets über ValueSets (DemJaNeinVS / DemJaNeinNzVS / DemJaNeinKaVS). SNOMED-Mapping: ja=373066001 (Yes), nein=373067005 (No). 

This Code system is referenced in the definition of the following value sets:

* [DEM Ja/Nein](ValueSet-dem-ja-nein.md)
* [DEM Ja/Nein/Keine Angabe](ValueSet-dem-ja-nein-ka-vs.md)
* [DEM Ja/Nein/Nicht zutreffend](ValueSet-dem-ja-nein-nz-vs.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "dem-antwort",
  "url" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/dem-antwort",
  "version" : "0.3.0",
  "name" : "DemAntwortCS",
  "title" : "DEM Antwortoptionen (Ja/Nein/Nicht zutreffend/Keine Angabe)",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-10-01T13:05:32+00:00",
  "publisher" : "BIH-CEI",
  "contact" : [{
    "name" : "BIH-CEI",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org/"
    }]
  }],
  "description" : "Gemeinsames CodeSystem für die Ja/Nein-Items des DEM. Frage-spezifische Subsets über ValueSets (DemJaNeinVS / DemJaNeinNzVS / DemJaNeinKaVS). SNOMED-Mapping: ja=373066001 (Yes), nein=373067005 (No).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 4,
  "concept" : [{
    "code" : "ja",
    "display" : "Ja",
    "designation" : [{
      "language" : "en",
      "value" : "Yes"
    }]
  },
  {
    "code" : "nein",
    "display" : "Nein",
    "designation" : [{
      "language" : "en",
      "value" : "No"
    }]
  },
  {
    "code" : "nicht-zutreffend",
    "display" : "Nicht zutreffend",
    "designation" : [{
      "language" : "en",
      "value" : "Not applicable"
    }]
  },
  {
    "code" : "keine-angabe",
    "display" : "Möchte ich nicht sagen",
    "designation" : [{
      "language" : "en",
      "value" : "Prefer not to say"
    }]
  }]
}

```
