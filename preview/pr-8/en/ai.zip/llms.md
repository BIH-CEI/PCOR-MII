# pcor-mii#0.1.0: PCOR-MII Implementation Guide(en)

## Pages

* [Startseite](index.md)
* [MHI](MHI.md)
* [PROMIS Cognitive Function SF 4a](PROMIS-Cognitive-Function.md)
* [Demographie](Demographie.md)
* [Bereitstellung](Bereitstellung.md)
* [PROMIS](PROMIS.md)
* [PROMIS-29 Profile v2.1](PROMIS-29.md)
* [PROMIS-33 Profile v2.1](PROMIS-33.md)
* [Anwendung](Implementation.md)
* [Artifacts Summary](artifacts.md)
* [PROMIS-16 Profile v2.1 (PROPr)](PROMIS-16.md)
* [Validierung](Validierung.md)
* [Release Notes](Release-Notes.md)

## Resources

### CodeSystems

* [DEM Antwortoptionen (Ja/Nein/Nicht zutreffend/Keine Angabe)](CodeSystem-dem-antwort.md)
* [DEM Beziehungsstatus (Codes)](CodeSystem-dem-beziehungsstatus.md)
* [DEM Haushaltseinkommen (Bänder)](CodeSystem-dem-einkommen.md)
* [DEM Erwerbsstatus (OECD)](CodeSystem-dem-erwerbsstatus.md)
* [DEM Geschlecht (Selbstbeschreibung)](CodeSystem-dem-geschlecht.md)
* [DEM Häufigkeit (5-stufig) (Codes)](CodeSystem-dem-haeufigkeit-5.md)
* [DEM Bildungsabschluss (ISCED-2011/KMK)](CodeSystem-dem-isced-de.md)
* [DEM Leichtigkeit Unterstützung (6-stufig) (Codes)](CodeSystem-dem-leichtigkeit-6.md)
* [DEM Rentenstatus (Codes)](CodeSystem-dem-rentenstatus.md)
* [DEM Urbanizität (Codes)](CodeSystem-dem-urbanizitaet.md)
* [DEM Zigaretten pro Tag (Bänder)](CodeSystem-dem-zigaretten-band.md)
* [MHI Anorexia-nervosa-Subtyp (Codes)](CodeSystem-mhi-an-subtyp.md)
* [MHI Chronische Erkrankungen (GIPS13) (Codes)](CodeSystem-mhi-chronisch.md)
* [MHI Diagnosegruppe (CPCOR) (Codes)](CodeSystem-mhi-cpcor-diag.md)
* [MHI Einnahmezeitpunkt Medikament (Codes)](CodeSystem-mhi-einnahmezeit.md)
* [MHI Gewichtsangabe (Codes)](CodeSystem-mhi-gewicht-angabe.md)
* [MHI Gewichtsmessung Methode (Codes)](CodeSystem-mhi-gewichtsmethode.md)
* [MHI Größenangabe (Codes)](CodeSystem-mhi-groesse-angabe.md)
* [PCOR Example General Health Self-Assessment](CodeSystem-pcor-example-general-health.md)

### ValueSets

* [DEM Beziehungsstatus](ValueSet-dem-beziehungsstatus-vs.md)
* [DEM Haushaltseinkommen](ValueSet-dem-einkommen-vs.md)
* [DEM Erwerbsstatus](ValueSet-dem-erwerbsstatus-vs.md)
* [DEM Geschlecht](ValueSet-dem-geschlecht-vs.md)
* [DEM Häufigkeit (5-stufig)](ValueSet-dem-haeufigkeit-5-vs.md)
* [DEM Bildungsabschluss (ISCED)](ValueSet-dem-isced-vs.md)
* [DEM Ja/Nein/Keine Angabe](ValueSet-dem-ja-nein-ka-vs.md)
* [DEM Ja/Nein/Nicht zutreffend](ValueSet-dem-ja-nein-nz-vs.md)
* [DEM Ja/Nein](ValueSet-dem-ja-nein.md)
* [DEM Leichtigkeit Unterstützung (6-stufig)](ValueSet-dem-leichtigkeit-6-vs.md)
* [DEM Rentenstatus](ValueSet-dem-rentenstatus-vs.md)
* [DEM Urbanizität](ValueSet-dem-urbanizitaet-vs.md)
* [DEM Zigaretten pro Tag](ValueSet-dem-zigaretten-band-vs.md)
* [MHI Anorexia-nervosa-Subtyp](ValueSet-mhi-an-subtyp-vs.md)
* [MHI Chronische Erkrankungen (GIPS13)](ValueSet-mhi-chronisch-vs.md)
* [MHI Diagnosegruppe (CPCOR)](ValueSet-mhi-cpcor-diag-vs.md)
* [MHI Einnahmezeitpunkt Medikament](ValueSet-mhi-einnahmezeit-vs.md)
* [MHI Gewichtsangabe](ValueSet-mhi-gewicht-angabe-vs.md)
* [MHI Gewichtsmessung Methode](ValueSet-mhi-gewichtsmethode-vs.md)
* [MHI Größenangabe](ValueSet-mhi-groesse-angabe-vs.md)
* [PCOR Example General Health Self-Assessment](ValueSet-pcor-example-general-health.md)

### ImplementationGuides

* [PCOR-MII Implementation Guide](ImplementationGuide-pcor-mii.md)

### Questionnaires

* [DEM — Demographics & Medical History](Questionnaire-DEM.md)
* [MHI — Medical History](Questionnaire-MHI.md)
* [PCOR Beispiel-Fragebogen](Questionnaire-PcorExampleQuestionnaire.md)

### Examples

* [pcor-mii-exa-patient (Patient)](Patient-pcor-mii-exa-patient.md)
* [DEMResponse (QuestionnaireResponse)](QuestionnaireResponse-DEMResponse.md)
* [MHIResponse (QuestionnaireResponse)](QuestionnaireResponse-MHIResponse.md)
* [pcor-mii-exa-example-response (QuestionnaireResponse)](QuestionnaireResponse-pcor-mii-exa-example-response.md)
* [pcor-mii-exa-promis-16-response (QuestionnaireResponse)](QuestionnaireResponse-pcor-mii-exa-promis-16-response.md)
* [pcor-mii-exa-promis-cognitive-function-response (QuestionnaireResponse)](QuestionnaireResponse-pcor-mii-exa-promis-cognitive-function-response.md)
