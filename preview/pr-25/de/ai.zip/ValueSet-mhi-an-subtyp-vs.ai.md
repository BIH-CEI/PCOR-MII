# MHI Anorexia-nervosa-Subtyp - PCOR-MII Implementation Guide v0.3.0

## ValueSet: MHI Anorexia-nervosa-Subtyp (Experimentell) 

 **References** 

* [MHI — Medical History](Questionnaire-MHI.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mhi-an-subtyp-vs",
  "url" : "https://bih-cei.github.io/PCOR-MII/ValueSet/mhi-an-subtyp-vs",
  "version" : "0.3.0",
  "name" : "MhiAnSubtypVS",
  "title" : "MHI Anorexia-nervosa-Subtyp",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-10-06T08:04:25+00:00",
  "publisher" : "BIH-CEI",
  "contact" : [{
    "name" : "BIH-CEI",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org/"
    }]
  }],
  "description" : "Subtyp der Anorexia nervosa (AN_subtyp).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/mhi-an-subtyp"
    }]
  }
}

```
