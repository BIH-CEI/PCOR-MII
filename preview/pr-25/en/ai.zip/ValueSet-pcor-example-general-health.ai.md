# PCOR Example General Health Self-Assessment - PCOR-MII Implementation Guide v0.3.0

## ValueSet: PCOR Example General Health Self-Assessment (Experimental) 

 **References** 

* [PCOR Beispiel-Fragebogen](Questionnaire-PcorExampleQuestionnaire.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "pcor-example-general-health",
  "url" : "https://bih-cei.github.io/PCOR-MII/ValueSet/pcor-example-general-health",
  "version" : "0.3.0",
  "name" : "PcorExampleGeneralHealthVS",
  "title" : "PCOR Example General Health Self-Assessment",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-10-13T07:18:17+00:00",
  "publisher" : "BIH-CEI",
  "contact" : [{
    "name" : "BIH-CEI",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org/"
    }]
  }],
  "description" : "ValueSet, das alle 5 Stufen der Selbsteinschätzung der allgemeinen Gesundheit aus dem Beispiel-Questionnaire abdeckt.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-example-general-health"
    }]
  }
}

```
