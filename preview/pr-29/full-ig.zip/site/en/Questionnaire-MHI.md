# MHI — Medical History - PCOR-MII Implementation Guide v0.9.0

## Questionnaire: MHI — Medical History (Experimental) 

*  [Tree view](#tabs-tree) 
*  [Sample Rendering](#tabs-sample) 
*  [Form Logic](#tabs-logic) 

### Test this Questionnaire

### Responses for this Questionnaire

There are currently no QuestionnaireResponse instances for this Questionnaire defined in this IG.



## Resource Content

```json
{
  "resourceType" : "Questionnaire",
  "id" : "MHI",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/isik/StructureDefinition/ISiKFormularDefinition"]
  },
  "language" : "de-DE",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "semver",
      "display" : "SemVer"
    }
  }],
  "url" : "https://bih-cei.github.io/PCOR-MII/Questionnaire/MHI",
  "version" : "0.9.0",
  "name" : "MHI",
  "title" : "MHI — Medical History",
  "status" : "draft",
  "experimental" : true,
  "subjectType" : ["Patient"],
  "date" : "2026-06-17",
  "publisher" : "BIH-CEI",
  "contact" : [{
    "name" : "BIH-CEI",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org/"
    }]
  }],
  "description" : "Medizinische Vorgeschichte (Kategorie MHI im PCOR-Item-Dictionary): Anthropometrie, Diagnosen/chronische Erkrankungen, Lifestyle (Rauchen/Alkohol/Substanzen), aktuelle Medikation und (AN-spezifisch) Gewichtsverlauf. SDC-Basis; kein PRO-Instrument. Die NTx-spezifische Transplantationsanamnese ist ein eigener Ergänzungsbogen (MHI-NTx).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "copyright" : "Die Items `GIPS13`, `GIPS56a`, `GIPS56b1`–`GIPS56b4`, `GIPS57a`, `GIPS57b` und `GIPS58` stammen aus dem GI-PS (doi:10.13109/zptm.2023.69.1.56). Die Eigentums-, Urheber-, Weitergabe- und Veröffentlichungsrechte verbleiben bei den jeweiligen Testautor:innen; das GI-PS oder Teile davon dürfen ohne deren Zustimmung nicht modifiziert, übersetzt oder an Dritte weitergegeben werden. Für PCOR-MII ist diese Zustimmung noch nicht dokumentiert — siehe Designentscheidungen. Die Verantwortung für Durchführung, Berechnung und Interpretation der Befragungsergebnisse liegt bei den Nutzenden. Der PCOR-MII-eigene FHIR-Inhalt (Struktur, Codes, Kodierung) unterliegt der Repository-Lizenz (CC-BY-4.0).",
  "code" : [{
    "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-questionnaire-catalogue",
    "code" : "mhi",
    "display" : "PCOR-MII Medical History (MHI)"
  }],
  "item" : [{
    "linkId" : "anthropometrie",
    "text" : "Körpermaße",
    "type" : "group",
    "item" : [{
      "linkId" : "Q_WB151",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "29463-7",
        "display" : "Körpergewicht"
      }],
      "text" : "Wie viel wiegen Sie?",
      "type" : "choice",
      "answerValueSet" : "https://bih-cei.github.io/PCOR-MII/ValueSet/mhi-gewicht-angabe-vs"
    },
    {
      "linkId" : "Q_WB151a",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "Q_WB151a"
      },
      {
        "system" : "http://loinc.org",
        "code" : "29463-7",
        "display" : "Körpergewicht"
      }],
      "text" : "Wie viel wiegen Sie? (kg)",
      "type" : "decimal",
      "enableWhen" : [{
        "question" : "Q_WB151",
        "operator" : "=",
        "answerCoding" : {
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/mhi-gewicht-angabe",
          "code" : "kg",
          "display" : "kg"
        }
      }]
    },
    {
      "linkId" : "Q_WB152",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "8302-2",
        "display" : "Körpergröße"
      }],
      "text" : "Wie groß sind Sie?",
      "type" : "choice",
      "answerValueSet" : "https://bih-cei.github.io/PCOR-MII/ValueSet/mhi-groesse-angabe-vs"
    },
    {
      "linkId" : "Q_WB152a",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "Q_WB152a"
      },
      {
        "system" : "http://loinc.org",
        "code" : "8302-2",
        "display" : "Körpergröße"
      }],
      "text" : "Wie groß sind Sie? (cm)",
      "type" : "decimal",
      "enableWhen" : [{
        "question" : "Q_WB152",
        "operator" : "=",
        "answerCoding" : {
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/mhi-groesse-angabe",
          "code" : "cm",
          "display" : "cm"
        }
      }]
    }]
  },
  {
    "linkId" : "diagnose",
    "text" : "Diagnose & chronische Erkrankungen",
    "type" : "group",
    "item" : [{
      "linkId" : "CPCOR-DIAG",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "CPCOR-DIAG"
      }],
      "text" : "Zu welcher Gruppe würden Sie sich zuordnen?",
      "type" : "choice",
      "repeats" : true,
      "answerValueSet" : "https://bih-cei.github.io/PCOR-MII/ValueSet/mhi-cpcor-diag-vs"
    },
    {
      "linkId" : "CPCOR_ONSET",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "CPCOR_ONSET"
      }],
      "text" : "Bitte geben Sie an, in welchem Jahr Sie Ihre Diagnose erhalten haben",
      "type" : "integer"
    },
    {
      "linkId" : "GIPS13",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "GIPS13"
      }],
      "text" : "Welche chronischen Erkrankungen haben Sie?",
      "type" : "choice",
      "repeats" : true,
      "answerValueSet" : "https://bih-cei.github.io/PCOR-MII/ValueSet/mhi-chronisch-vs"
    }]
  },
  {
    "linkId" : "lifestyle",
    "text" : "Rauchen, Alkohol & Substanzen",
    "type" : "group",
    "item" : [{
      "linkId" : "GIPS57a",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "GIPS57a"
      },
      {
        "system" : "http://loinc.org",
        "code" : "72166-2",
        "display" : "Raucherstatus"
      }],
      "text" : "Rauchen Sie (einschließlich E-Zigaretten)?",
      "type" : "choice",
      "answerOption" : [{
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001",
          "display" : "Yes"
        }
      },
      {
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373067005",
          "display" : "No"
        }
      }]
    },
    {
      "linkId" : "GIPS57b",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "GIPS57b"
      },
      {
        "system" : "http://loinc.org",
        "code" : "64218-1",
        "display" : "How many cigarettes do you smoke per day now [PhenX]"
      }],
      "text" : "Wenn ja: Wie viele Zigaretten rauchen Sie pro Tag?",
      "type" : "choice",
      "enableWhen" : [{
        "question" : "GIPS57a",
        "operator" : "=",
        "answerCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001"
        }
      }],
      "answerValueSet" : "https://bih-cei.github.io/PCOR-MII/ValueSet/dem-zigaretten-band-vs"
    },
    {
      "linkId" : "GIPS56a",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "GIPS56a"
      },
      {
        "system" : "http://loinc.org",
        "code" : "11331-6",
        "display" : "History of Alcohol use"
      }],
      "text" : "Trinken Sie Alkohol?",
      "type" : "choice",
      "answerOption" : [{
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001",
          "display" : "Yes"
        }
      },
      {
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373067005",
          "display" : "No"
        }
      }]
    },
    {
      "linkId" : "GIPS56b1",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "GIPS56b1"
      }],
      "text" : "Haben Sie jemals daran gedacht, weniger zu trinken? (CAGE 1)",
      "type" : "choice",
      "enableWhen" : [{
        "question" : "GIPS56a",
        "operator" : "=",
        "answerCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001"
        }
      }],
      "answerOption" : [{
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001",
          "display" : "Yes"
        }
      },
      {
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373067005",
          "display" : "No"
        }
      }]
    },
    {
      "linkId" : "GIPS56b2",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "GIPS56b2"
      }],
      "text" : "Haben Sie sich schon einmal darüber geärgert, dass Sie von anderen wegen Ihres Alkoholkonsums kritisiert wurden? (CAGE 2)",
      "type" : "choice",
      "enableWhen" : [{
        "question" : "GIPS56a",
        "operator" : "=",
        "answerCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001"
        }
      }],
      "answerOption" : [{
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001",
          "display" : "Yes"
        }
      },
      {
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373067005",
          "display" : "No"
        }
      }]
    },
    {
      "linkId" : "GIPS56b3",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "GIPS56b3"
      }],
      "text" : "Haben Sie sich jemals wegen Ihres Trinkens schuldig gefühlt? (CAGE 3)",
      "type" : "choice",
      "enableWhen" : [{
        "question" : "GIPS56a",
        "operator" : "=",
        "answerCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001"
        }
      }],
      "answerOption" : [{
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001",
          "display" : "Yes"
        }
      },
      {
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373067005",
          "display" : "No"
        }
      }]
    },
    {
      "linkId" : "GIPS56b4",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "GIPS56b4"
      }],
      "text" : "Haben Sie jemals morgens als erstes Alkohol getrunken, um sich nervlich zu stabilisieren oder einen Kater loszuwerden? (CAGE 4 — Eye-opener)",
      "type" : "choice",
      "enableWhen" : [{
        "question" : "GIPS56a",
        "operator" : "=",
        "answerCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001"
        }
      }],
      "answerOption" : [{
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001",
          "display" : "Yes"
        }
      },
      {
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373067005",
          "display" : "No"
        }
      }]
    },
    {
      "linkId" : "GIPS58",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "GIPS58"
      },
      {
        "system" : "http://loinc.org",
        "code" : "96873-5",
        "display" : "Illegal or recreational drug(s) used in past 3 months"
      }],
      "text" : "Nutzen Sie hin und wieder eine der folgenden Substanzen: Cannabis, Ecstasy, Kokain, Amphetamine, Anabolika, Crystal?",
      "type" : "choice",
      "answerOption" : [{
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001",
          "display" : "Yes"
        }
      },
      {
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373067005",
          "display" : "No"
        }
      }]
    }]
  },
  {
    "linkId" : "medikation",
    "text" : "Aktuelle Medikamente",
    "type" : "group",
    "item" : [{
      "linkId" : "medication1",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "medication1"
      }],
      "text" : "Nehmen Sie aktuell Medikamente (einschließlich der Pille) ein?",
      "type" : "choice",
      "answerOption" : [{
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001",
          "display" : "Yes"
        }
      },
      {
        "valueCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373067005",
          "display" : "No"
        }
      }]
    },
    {
      "linkId" : "medication_text",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "medication_text"
      }],
      "text" : "Bitte nennen Sie alle Medikamente, die Sie aktuell regelmäßig oder bei Bedarf einnehmen.",
      "type" : "text",
      "enableWhen" : [{
        "question" : "medication1",
        "operator" : "=",
        "answerCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001"
        }
      }]
    },
    {
      "linkId" : "MEDI_01",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "MEDI_01"
      }],
      "text" : "Wie viele Medikamente nehmen Sie insgesamt momentan ein?",
      "type" : "integer",
      "enableWhen" : [{
        "question" : "medication1",
        "operator" : "=",
        "answerCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001"
        }
      }]
    },
    {
      "linkId" : "medi_02_01",
      "text" : "Medikament 1",
      "type" : "group",
      "enableWhen" : [{
        "question" : "medication1",
        "operator" : "=",
        "answerCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001"
        }
      }],
      "item" : [{
        "linkId" : "medi_02_name_01",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_name_01"
        }],
        "text" : "Name des Medikaments",
        "type" : "string"
      },
      {
        "linkId" : "medi_02_onset_01",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_onset_01"
        }],
        "text" : "Seit wann nehmen Sie dieses Medikament ein?",
        "type" : "string"
      },
      {
        "linkId" : "medi_02_dose_01",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_dose_01"
        }],
        "text" : "Falls bekannt: Wie ist die Dosierung dieses Medikaments?",
        "type" : "string"
      },
      {
        "linkId" : "medi_02_time_01",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_time_01"
        }],
        "text" : "Wann nehmen Sie dieses Medikament ein?",
        "type" : "choice",
        "answerValueSet" : "https://bih-cei.github.io/PCOR-MII/ValueSet/mhi-einnahmezeit-vs"
      },
      {
        "linkId" : "medi_02_frequency_01",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_frequency_01"
        }],
        "text" : "Wie häufig nehmen Sie dieses Medikament pro Woche ein?",
        "type" : "string"
      }]
    },
    {
      "linkId" : "medi_02_02",
      "text" : "Medikament 2",
      "type" : "group",
      "enableWhen" : [{
        "question" : "medication1",
        "operator" : "=",
        "answerCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001"
        }
      }],
      "item" : [{
        "linkId" : "medi_02_name_02",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_name_02"
        }],
        "text" : "Name des Medikaments",
        "type" : "string"
      },
      {
        "linkId" : "medi_02_onset_02",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_onset_02"
        }],
        "text" : "Seit wann nehmen Sie dieses Medikament ein?",
        "type" : "string"
      },
      {
        "linkId" : "medi_02_dose_02",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_dose_02"
        }],
        "text" : "Falls bekannt: Wie ist die Dosierung dieses Medikaments?",
        "type" : "string"
      },
      {
        "linkId" : "medi_02_time_02",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_time_02"
        }],
        "text" : "Wann nehmen Sie dieses Medikament ein?",
        "type" : "choice",
        "answerValueSet" : "https://bih-cei.github.io/PCOR-MII/ValueSet/mhi-einnahmezeit-vs"
      },
      {
        "linkId" : "medi_02_frequency_02",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_frequency_02"
        }],
        "text" : "Wie häufig nehmen Sie dieses Medikament pro Woche ein?",
        "type" : "string"
      }]
    },
    {
      "linkId" : "medi_02_03",
      "text" : "Medikament 3",
      "type" : "group",
      "enableWhen" : [{
        "question" : "medication1",
        "operator" : "=",
        "answerCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001"
        }
      }],
      "item" : [{
        "linkId" : "medi_02_name_03",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_name_03"
        }],
        "text" : "Name des Medikaments",
        "type" : "string"
      },
      {
        "linkId" : "medi_02_onset_03",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_onset_03"
        }],
        "text" : "Seit wann nehmen Sie dieses Medikament ein?",
        "type" : "string"
      },
      {
        "linkId" : "medi_02_dose_03",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_dose_03"
        }],
        "text" : "Falls bekannt: Wie ist die Dosierung dieses Medikaments?",
        "type" : "string"
      },
      {
        "linkId" : "medi_02_time_03",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_time_03"
        }],
        "text" : "Wann nehmen Sie dieses Medikament ein?",
        "type" : "choice",
        "answerValueSet" : "https://bih-cei.github.io/PCOR-MII/ValueSet/mhi-einnahmezeit-vs"
      },
      {
        "linkId" : "medi_02_frequency_03",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_frequency_03"
        }],
        "text" : "Wie häufig nehmen Sie dieses Medikament pro Woche ein?",
        "type" : "string"
      }]
    },
    {
      "linkId" : "medi_02_04",
      "text" : "Medikament 4",
      "type" : "group",
      "enableWhen" : [{
        "question" : "medication1",
        "operator" : "=",
        "answerCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001"
        }
      }],
      "item" : [{
        "linkId" : "medi_02_name_04",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_name_04"
        }],
        "text" : "Name des Medikaments",
        "type" : "string"
      },
      {
        "linkId" : "medi_02_onset_04",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_onset_04"
        }],
        "text" : "Seit wann nehmen Sie dieses Medikament ein?",
        "type" : "string"
      },
      {
        "linkId" : "medi_02_dose_04",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_dose_04"
        }],
        "text" : "Falls bekannt: Wie ist die Dosierung dieses Medikaments?",
        "type" : "string"
      },
      {
        "linkId" : "medi_02_time_04",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_time_04"
        }],
        "text" : "Wann nehmen Sie dieses Medikament ein?",
        "type" : "choice",
        "answerValueSet" : "https://bih-cei.github.io/PCOR-MII/ValueSet/mhi-einnahmezeit-vs"
      },
      {
        "linkId" : "medi_02_frequency_04",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_frequency_04"
        }],
        "text" : "Wie häufig nehmen Sie dieses Medikament pro Woche ein?",
        "type" : "string"
      }]
    },
    {
      "linkId" : "medi_02_05",
      "text" : "Medikament 5",
      "type" : "group",
      "enableWhen" : [{
        "question" : "medication1",
        "operator" : "=",
        "answerCoding" : {
          "system" : "http://snomed.info/sct",
          "code" : "373066001"
        }
      }],
      "item" : [{
        "linkId" : "medi_02_name_05",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_name_05"
        }],
        "text" : "Name des Medikaments",
        "type" : "string"
      },
      {
        "linkId" : "medi_02_onset_05",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_onset_05"
        }],
        "text" : "Seit wann nehmen Sie dieses Medikament ein?",
        "type" : "string"
      },
      {
        "linkId" : "medi_02_dose_05",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_dose_05"
        }],
        "text" : "Falls bekannt: Wie ist die Dosierung dieses Medikaments?",
        "type" : "string"
      },
      {
        "linkId" : "medi_02_time_05",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_time_05"
        }],
        "text" : "Wann nehmen Sie dieses Medikament ein?",
        "type" : "choice",
        "answerValueSet" : "https://bih-cei.github.io/PCOR-MII/ValueSet/mhi-einnahmezeit-vs"
      },
      {
        "linkId" : "medi_02_frequency_05",
        "code" : [{
          "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
          "code" : "medi_02_frequency_05"
        }],
        "text" : "Wie häufig nehmen Sie dieses Medikament pro Woche ein?",
        "type" : "string"
      }]
    }]
  },
  {
    "linkId" : "gewicht-an",
    "text" : "Gewichtsverlauf (Szenario Anorexia nervosa)",
    "type" : "group",
    "item" : [{
      "linkId" : "weight_outpatient_1",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "weight_outpatient_1"
      },
      {
        "system" : "http://loinc.org",
        "code" : "29463-7",
        "display" : "Körpergewicht"
      }],
      "text" : "Ambulant gemessenes Körpergewicht (kg) — empfohlen beim Hausarzt mit geeichter Waage",
      "type" : "decimal"
    },
    {
      "linkId" : "weight_outpatient_2",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "weight_outpatient_2"
      }],
      "text" : "Wie haben Sie das oben genannte Gewicht ermittelt?",
      "type" : "choice",
      "answerValueSet" : "https://bih-cei.github.io/PCOR-MII/ValueSet/mhi-gewichtsmethode-vs"
    },
    {
      "linkId" : "weight_inpatient",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "weight_inpatient"
      },
      {
        "system" : "http://loinc.org",
        "code" : "29463-7",
        "display" : "Körpergewicht"
      }],
      "text" : "Stationäres Körpergewicht — wie viel wiegen Sie aktuell in kg?",
      "type" : "decimal"
    },
    {
      "linkId" : "weight_discharge",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "weight_discharge"
      },
      {
        "system" : "http://loinc.org",
        "code" : "29463-7",
        "display" : "Körpergewicht"
      }],
      "text" : "Körpergewicht bei Entlassung — wie viel wiegen Sie aktuell in kg?",
      "type" : "decimal"
    },
    {
      "linkId" : "AN_subtyp",
      "code" : [{
        "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/pcor-item-dictionary",
        "code" : "AN_subtyp"
      }],
      "text" : "Welchem Subtyp der Anorexia nervosa würden Sie sich zuordnen?",
      "type" : "choice",
      "answerValueSet" : "https://bih-cei.github.io/PCOR-MII/ValueSet/mhi-an-subtyp-vs"
    }]
  }]
}

```
