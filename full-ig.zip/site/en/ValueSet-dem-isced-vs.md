# DEM Bildungsabschluss (ISCED) - PCOR-MII Implementation Guide v0.9.0

## ValueSet: DEM Bildungsabschluss (ISCED) (Experimental) 

 **References** 

* [DEM — Demographics & Medical History](Questionnaire-DEM.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "dem-isced-vs",
  "url" : "https://bih-cei.github.io/PCOR-MII/ValueSet/dem-isced-vs",
  "version" : "0.9.0",
  "name" : "DemIscedVS",
  "title" : "DEM Bildungsabschluss (ISCED)",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-11-16T14:40:34+00:00",
  "publisher" : "BIH-CEI",
  "contact" : [{
    "name" : "BIH-CEI",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org/"
    }]
  }],
  "description" : "Höchster Bildungsabschluss (Q_ISCED).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/dem-isced-de"
    }]
  }
}

```
