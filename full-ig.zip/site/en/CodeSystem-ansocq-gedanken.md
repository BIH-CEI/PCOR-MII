# ANSOCQ Item 14 — Gedanken an Nahrung und Gewicht (Codes) - PCOR-MII Implementation Guide v0.9.0

## CodeSystem: ANSOCQ Item 14 — Gedanken an Nahrung und Gewicht (Codes) (Experimental) 

This Code system is referenced in the definition of the following value sets:

* [ANSOCQ Item 14 — Gedanken an Nahrung und Gewicht](ValueSet-ansocq-gedanken-vs.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ansocq-gedanken",
  "url" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/ansocq-gedanken",
  "version" : "0.9.0",
  "name" : "AnsocqGedankenCS",
  "title" : "ANSOCQ Item 14 — Gedanken an Nahrung und Gewicht (Codes)",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-11-16T14:40:34+00:00",
  "publisher" : "BIH-CEI",
  "contact" : [{
    "name" : "BIH-CEI",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org/"
    }]
  }],
  "description" : "Fünf Feststellungen des ANSOCQ-Items 14 (Zeit mit Gedanken an Nahrung und Gewicht), Stadien 1-5. itemWeight-Property je Konzept.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 5,
  "property" : [{
    "code" : "itemWeight",
    "uri" : "http://hl7.org/fhir/concept-properties#itemWeight",
    "description" : "Stadium der Veränderungsbereitschaft (1-5).",
    "type" : "decimal"
  }],
  "concept" : [{
    "code" : "1",
    "display" : "There is nothing wrong with the amount of time I spend thinking about food and my weight.",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Die Zeitdauer, die ich mit Gedanken an Nahrung und Gewicht verbringe, ist völlig in Ordnung."
    },
    {
      "language" : "de",
      "value" : "Die Zeitdauer, die ich mit Gedanken an Nahrung und Gewicht verbringe, ist völlig in Ordnung."
    }],
    "property" : [{
      "code" : "itemWeight",
      "valueDecimal" : 1
    }]
  },
  {
    "code" : "2",
    "display" : "The amount of time I spend thinking about food and my weight is a problem sometimes.",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Die Zeitdauer, die ich mit Gedanken an Nahrung und Gewicht verbringe, ist manchmal ein Problem für mich."
    },
    {
      "language" : "de",
      "value" : "Die Zeitdauer, die ich mit Gedanken an Nahrung und Gewicht verbringe, ist manchmal ein Problem für mich."
    }],
    "property" : [{
      "code" : "itemWeight",
      "valueDecimal" : 2
    }]
  },
  {
    "code" : "3",
    "display" : "I have decided that I need to use strategies to help me reduce the amount of time I spend thinking about food and my weight.",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Ich habe mich entschieden, dass ich Strategien entwickeln muss, um die Zeitdauer zu reduzieren, die ich mit Gedanken an Nahrung und Gewicht verbringe."
    },
    {
      "language" : "de",
      "value" : "Ich habe mich entschieden, dass ich Strategien entwickeln muss, um die Zeitdauer zu reduzieren, die ich mit Gedanken an Nahrung und Gewicht verbringe."
    }],
    "property" : [{
      "code" : "itemWeight",
      "valueDecimal" : 3
    }]
  },
  {
    "code" : "4",
    "display" : "I am using strategies to help me reduce the amount of time I spend thinking about food and my weight.",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Ich benutze Strategien, die mir helfen, die Zeitdauer zu reduzieren, die ich mit Gedanken an Nahrung und Gewicht verbringe."
    },
    {
      "language" : "de",
      "value" : "Ich benutze Strategien, die mir helfen, die Zeitdauer zu reduzieren, die ich mit Gedanken an Nahrung und Gewicht verbringe."
    }],
    "property" : [{
      "code" : "itemWeight",
      "valueDecimal" : 4
    }]
  },
  {
    "code" : "5",
    "display" : "I used to spend too much time thinking about food and my weight which I have managed to reduce and am working to keep it this way.",
    "designation" : [{
      "language" : "de-CH",
      "value" : "Ich verbrachte früher zu viel Zeit mit Gedanken an Nahrung und Gewicht, was ich nun reduzieren konnte, und ich arbeite daran, dass dies so bleibt."
    },
    {
      "language" : "de",
      "value" : "Ich verbrachte früher zu viel Zeit mit Gedanken an Nahrung und Gewicht, was ich nun reduzieren konnte, und ich arbeite daran, dass dies so bleibt."
    }],
    "property" : [{
      "code" : "itemWeight",
      "valueDecimal" : 5
    }]
  }]
}

```
