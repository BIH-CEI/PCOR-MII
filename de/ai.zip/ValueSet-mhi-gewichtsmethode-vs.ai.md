# MHI Gewichtsmessung Methode - PCOR-MII Implementation Guide v0.2.0

## ValueSet: MHI Gewichtsmessung Methode (Experimentell) 

 
Wie wurde das Gewicht ermittelt? (weight_outpatient_2). 

 **References** 

* [MHI — Medical History](Questionnaire-MHI.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mhi-gewichtsmethode-vs",
  "url" : "https://bih-cei.github.io/PCOR-MII/ValueSet/mhi-gewichtsmethode-vs",
  "version" : "0.2.0",
  "name" : "MhiGewichtsmethodeVS",
  "title" : "MHI Gewichtsmessung Methode",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-09-02T03:42:42+00:00",
  "publisher" : "BIH-CEI",
  "contact" : [{
    "name" : "BIH-CEI",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.bihealth.org/"
    }]
  }],
  "description" : "Wie wurde das Gewicht ermittelt? (weight_outpatient_2).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://bih-cei.github.io/PCOR-MII/CodeSystem/mhi-gewichtsmethode"
    }]
  }
}

```
