# PROMIS - PCOR-MII Implementation Guide v0.9.0

## PROMIS

**PROMIS®** (Patient-Reported Outcomes Measurement Information System) ist ein vom US National Institutes of Health (NIH) gegründetes Instrumentariums-Framework zur standardisierten Erfassung patientenberichteter Gesundheitszustände über mehrere Domänen hinweg (z.B. Physical Function, Anxiety, Depression, Fatigue, Sleep Disturbance, Pain Interference, Social Function, Cognitive Function).

Die PROMIS Health Organization (PHO) pflegt die Item-Banken und Profile international; das **PROMIS National Center Deutschland** (CPCOR Charité, Leitung Felix Fischer) verantwortet die validierten deutschen Übersetzungen.

### PROMIS-Instrumente in PCOR-MII

PCOR-MII referenziert die im MII PRO-Modul gepflegten PROMIS-Questionnaires — kein eigener Nachbau:

* [**PROMIS-33 Profile v2.1**](PROMIS-33.md) — Multi-Domain HRQoL inkl. Cognitive Function, 33 Items über 8 Domänen (**geplant, noch nicht im MII PRO-Modul implementiert**)
* [**PROMIS-29 Profile v2.1**](PROMIS-29.md) — Multi-Domain HRQoL, 29 Items über 7 Domänen + Schmerzintensität
* [**PROMIS Cognitive Function SF 4a**](PROMIS-Cognitive-Function.md) — kognitive Funktion (Selbstauskunft), 4 Items
* [**PROMIS-16 Profile v2.1 (PROPr)**](PROMIS-16.md) — ultrakurz, 16 Items über 8 Domänen (inkl. Cognitive Function)

#### Ausnahme: PROMIS Global Health (Global01/Global02)

Zwei Einzelitems der **PROMIS Scale v1.2 – Global Health** werden in PCOR-MII erhoben, sind im MII PRO-Modul (geprüft gegen `2026.6.0`) aber nicht abgebildet — weder als Questionnaire noch als Katalogeintrag:

| | | |
| :--- | :--- | :--- |
| `Global01` | [`61577-3`](https://loinc.org/61577-3) | Wie würden Sie Ihren Gesundheitszustand insgesamt beschreiben? |
| `Global02` | [`61578-1`](https://loinc.org/61578-1) | Wie würden Sie Ihre Lebensqualität insgesamt beschreiben? |

Antwortskala beider Items ist die LOINC-Answerlist [`LL4280-5`](https://loinc.org/LL4280-5) (5 = Ausgezeichnet · 4 = Sehr gut · 3 = Gut · 2 = Einigermaßen · 1 = Schlecht), abgebildet im ValueSet [`promis-global-skala-5-vs`](ValueSet-promis-global-skala-5-vs.md).

Die vollständige 10-Item-Skala (LOINC-Panel [`85524-7`](https://loinc.org/85524-7) „PROMIS short form - global - version 1.2") ist seit MII PRO 2027.0.0-ballot.2 als `mii-qst-pro-promis-global-health` im Modul enthalten (Status `draft`; die offizielle deutsche Übersetzung liegt dort bisher nur für Global01, Global02 und Global07 vor). PCOR-MII stellt weiterhin den lokalen Questionnaire [`PROMISGH`](Questionnaire-PROMISGH.md) mit exakt diesen zwei Items bereit, seit 0.9.0 per `derivedFrom` als 2-Item-Zuschnitt der Modul-Definition ausgewiesen. **Offen** sind die `linkId`s (Dictionary `Global01`/`Global02` gegen upstream `promis-global01`/`promis-global02`) und ob der lokale Bogen zugunsten der Upstream-Definition entfällt — siehe [Rechtelage und offene Punkte](Rechtelage.md#promis-gh).

Die PROMIS-Scores Global Physical Health (`71972-4`) und Global Mental Health (`71970-8`) sind aus diesen beiden Items **nicht** berechenbar — sie setzen je vier Items der Gesamtskala voraus. Global01 und Global02 werden daher als Einzelindikatoren verwendet.

Das dritte GHS-Einzelitem `Global07` („PROMIS Numeric Rating Scale – Pain Intensity 1a", LOINC `61583-1`) braucht kein eigenes Artefakt: es ist als `promis-global07` im referenzierten [PROMIS-29](PROMIS-29.md) enthalten.

### Lizenz & Copyright

PROMIS-Ressourcen unterliegen dem 4-Schichten-Modell aus dem MII PRO-Modul:

1. **FHIR-Resource-Struktur**© Medizininformatik-Initiative (CC-BY 4.0)
1. **PROMIS-Items**© PROMIS Health Organization (Northwestern University)
1. **Offizielle deutsche Übersetzungen**bereitgestellt durch PCOR-MII, kuratiert durch PROMIS National Center Deutschland
1. **LOINC-Codes**© Regenstrief Institute

Details und Nutzungsanfragen: [PROMIS-Lizenzierung im MII PRO-Modul](https://medizininformatik-initiative.github.io/kerndatensatzmodul-proms/promis.html).

### Item-Überlapp

PROMIS-29 und PROMIS-16 überlappen sich in **11 der 16 PROMIS-16-Items** (gegen die Questionnaires im Dependency-Paket verifiziert): `pfa21`, `pfa23`, `edanx40`, `edanx41`, `eddep29`, `eddep41`, `hi7`, `an3`, `srpper46-caps`, `painin9`, `painin31`.

**PROMIS-16 ist kein PROMIS-29-Subset.** Fünf Items sind PROMIS-16-spezifisch, und sie verteilen sich auf drei Domänen — nicht nur auf Cognitive Function: `sleep25` und `sleep90` (Sleep), `srpper31-caps` (Social Roles), `pc27r` und `pc-caps3r` (Cognitive Function). Praktische Konsequenz: Wer **PROMIS-29 + Cognitive Function SF 4a** erhebt, kann daraus **keinen vollständigen PROMIS-16 rekonstruieren** — auch nicht die Cognitive-Function-Domäne, denn die SF 4a nutzt vier andere Items (`pc2r`, `pc35r`, `pc36r`, `pc42r`).

Bei kombinierter Erfassung sollten die 11 überlappenden Items nicht doppelt erhoben werden — eine Item-basierte Score-Architektur ist im MII PRO-Modul für 2027 geplant.

### Quellen

* Übergeordneter IG: [MII PRO-Modul IG-Doku](https://medizininformatik-initiative.github.io/kerndatensatzmodul-proms/index.html) · [PRO-Bibliothek PROMIS-Sektion](https://medizininformatik-initiative.github.io/kerndatensatzmodul-proms/promis.html) · [Raw-Package](https://medizininformatik-initiative.github.io/kerndatensatzmodul-proms/package.tgz)
* PROMIS Health Organization: [healthmeasures.net](https://www.healthmeasures.net/explore-measurement-systems/promis)
* PROMIS National Center Deutschland (CPCOR Charité): Felix Fischer

