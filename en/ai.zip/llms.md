# pcor-mii#0.1.0: PCOR-MII Implementation Guide(en)

## Pages

* [Startseite](index.md)
* [PROMIS Cognitive Function SF 4a](PROMIS-Cognitive-Function.md)
* [PROMIS-29 Profile v2.1](PROMIS-29.md)
* [Anwendung](Implementation.md)
* [Artifacts Summary](artifacts.md)
* [PROMIS-16 Profile v2.1 (PROPr)](PROMIS-16.md)
* [Fragebögen](Questionnaires.md)
* [Release Notes](Release-Notes.md)

## Resources

### CodeSystems

* [DEM Antwortoptionen (Ja/Nein/Nicht zutreffend/Keine Angabe)](CodeSystem-dem-antwort.md)
* [DEM Beziehungsstatus (Codes)](CodeSystem-dem-beziehungsstatus.md)
* [DEM Haushaltseinkommen (Bänder)](CodeSystem-dem-einkommen.md)
* [DEM Erwerbsstatus (OECD)](CodeSystem-dem-erwerbsstatus.md)
* [DEM Geschlecht (Selbstbeschreibung)](CodeSystem-dem-geschlecht.md)
* [DEM Häufigkeit (5-stufig) (Codes)](CodeSystem-dem-haeufigkeit-5.md)
* [DEM Bildungsabschluss (ISCED-2011/KMK)](CodeSystem-dem-isced-de.md)
* [DEM Leichtigkeit Unterstützung (6-stufig) (Codes)](CodeSystem-dem-leichtigkeit-6.md)
* [DEM Rentenstatus (Codes)](CodeSystem-dem-rentenstatus.md)
* [DEM Urbanizität (Codes)](CodeSystem-dem-urbanizitaet.md)
* [DEM Zigaretten pro Tag (Bänder)](CodeSystem-dem-zigaretten-band.md)

### ValueSets

* [DEM Beziehungsstatus](ValueSet-dem-beziehungsstatus-vs.md)
* [DEM Haushaltseinkommen](ValueSet-dem-einkommen-vs.md)
* [DEM Erwerbsstatus](ValueSet-dem-erwerbsstatus-vs.md)
* [DEM Geschlecht](ValueSet-dem-geschlecht-vs.md)
* [DEM Häufigkeit (5-stufig)](ValueSet-dem-haeufigkeit-5-vs.md)
* [DEM Bildungsabschluss (ISCED)](ValueSet-dem-isced-vs.md)
* [DEM Ja/Nein/Keine Angabe](ValueSet-dem-ja-nein-ka-vs.md)
* [DEM Ja/Nein/Nicht zutreffend](ValueSet-dem-ja-nein-nz-vs.md)
* [DEM Ja/Nein](ValueSet-dem-ja-nein.md)
* [DEM Leichtigkeit Unterstützung (6-stufig)](ValueSet-dem-leichtigkeit-6-vs.md)
* [DEM Rentenstatus](ValueSet-dem-rentenstatus-vs.md)
* [DEM Urbanizität](ValueSet-dem-urbanizitaet-vs.md)
* [DEM Zigaretten pro Tag](ValueSet-dem-zigaretten-band-vs.md)

### ImplementationGuides

* [PCOR-MII Implementation Guide](ImplementationGuide-pcor-mii.md)

### Questionnaires

* [DEM — Demographics & Medical History](Questionnaire-DEM.md)
* [PCOR Beispiel-Fragebogen](Questionnaire-PcorExampleQuestionnaire.md)
